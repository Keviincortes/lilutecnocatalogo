#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scripts para Gestión del Catálogo LiluTecno
Permite agregar, editar y actualizar productos desde la línea de comandos
"""

import pandas as pd
import json
import os
import shutil
from datetime import datetime
import sys

class GestorCatalogo:
    def __init__(self):
        self.archivo_excel = 'user_input_files/INVENTARIO LiluTecno (1).xlsx'
        self.archivo_json = 'lilutecno-catalogo/public/productos_con_imagenes.json'
        self.backup_dir = 'backups_catalogo'
        
        # Crear directorio de backups
        os.makedirs(self.backup_dir, exist_ok=True)
    
    def crear_backup(self):
        """Crear backup antes de modificar"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if os.path.exists(self.archivo_json):
            backup_file = f"{self.backup_dir}/productos_backup_{timestamp}.json"
            shutil.copy2(self.archivo_json, backup_file)
            print(f"✅ Backup creado: {backup_file}")
    
    def cargar_productos(self):
        """Cargar productos desde JSON"""
        try:
            with open(self.archivo_json, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print("❌ No se encontró el archivo de productos")
            return []
    
    def guardar_productos(self, productos):
        """Guardar productos en JSON"""
        with open(self.archivo_json, 'w', encoding='utf-8') as f:
            json.dump(productos, f, indent=2, ensure_ascii=False)
        print("✅ Productos guardados exitosamente")
    
    def agregar_producto(self, producto_data):
        """Agregar nuevo producto"""
        self.crear_backup()
        productos = self.cargar_productos()
        
        # Asignar imagen por defecto basada en categoría
        imagen_default = self.asignar_imagen_categoria(producto_data.get('CATEGORIA', ''))
        
        nuevo_producto = {
            "Unnamed: 0": "",
            "PRODUCTO": producto_data['nombre'],
            "IMAGEN 1": "",
            "IMAGEN 2": "",
            "IMAGEN 3": "",
            "IMAGEN 4": "",
            "IMAGEN 5": "",
            "DESCRICION": producto_data.get('descripcion', ''),
            "CATEGORIA": producto_data.get('categoria', ''),
            "STOCK INICIAL": producto_data.get('stock_inicial', 0),
            "ENTRADAS": 0,
            "SALIDAS": 0,
            "STOK ACTUAL": producto_data.get('stock_actual', 0),
            "PRECIO DE VENTA": producto_data.get('precio_venta', 0),
            "COSTO": producto_data.get('costo', 0),
            "PROVEEDOR": producto_data.get('proveedor', ''),
            "OBSERVACIONES": producto_data.get('observaciones', ''),
            "imagen_principal": imagen_default,
            "imagenes": [imagen_default]
        }
        
        productos.append(nuevo_producto)
        self.guardar_productos(productos)
        print(f"✅ Producto '{producto_data['nombre']}' agregado exitosamente")
    
    def asignar_imagen_categoria(self, categoria):
        """Asignar imagen por defecto según categoría"""
        mapeo_imagenes = {
            "TELEVISOR": "imagenes_productos/televisor_65_smart_tv_1.jpg",
            "ENTRETENIMIENTO": "imagenes_productos/mini_proyector_led_300_5.jpg",
            "ACCESORIOS": "imagenes_productos/cable_usb_c_11.jpg",
            "AUDIO": "imagenes_productos/altavoz_bluetooth_15.jpg",
            "GAMING": "imagenes_productos/mouse_gaming_8.jpg",
            "CARGADORES": "imagenes_productos/cargador_portatil_13.jpg"
        }
        return mapeo_imagenes.get(categoria.upper(), "imagenes_productos/televisor_65_smart_tv_1.jpg")
    
    def buscar_producto(self, termino_busqueda):
        """Buscar producto por nombre"""
        productos = self.cargar_productos()
        resultados = []
        
        for i, producto in enumerate(productos):
            if termino_busqueda.lower() in producto['PRODUCTO'].lower():
                resultados.append((i, producto))
        
        return resultados
    
    def editar_producto(self, indice, nuevos_datos):
        """Editar producto existente"""
        self.crear_backup()
        productos = self.cargar_productos()
        
        if 0 <= indice < len(productos):
            for campo, valor in nuevos_datos.items():
                if campo in productos[indice]:
                    productos[indice][campo] = valor
            
            self.guardar_productos(productos)
            print(f"✅ Producto editado exitosamente")
        else:
            print("❌ Índice de producto inválido")
    
    def eliminar_producto(self, indice):
        """Eliminar producto"""
        self.crear_backup()
        productos = self.cargar_productos()
        
        if 0 <= indice < len(productos):
            producto_eliminado = productos.pop(indice)
            self.guardar_productos(productos)
            print(f"✅ Producto '{producto_eliminado['PRODUCTO']}' eliminado exitosamente")
        else:
            print("❌ Índice de producto inválido")
    
    def listar_productos(self, limite=10):
        """Listar productos"""
        productos = self.cargar_productos()
        print(f"\n📦 CATÁLOGO LILUTECNO - {len(productos)} productos")
        print("=" * 80)
        
        for i, producto in enumerate(productos[:limite]):
            precio = f"${producto['PRECIO DE VENTA']:,}" if producto['PRECIO DE VENTA'] else "Sin precio"
            stock = producto['STOK ACTUAL'] if producto['STOK ACTUAL'] else 0
            print(f"{i:3d}. {producto['PRODUCTO'][:50]:<50} | {precio:>12} | Stock: {stock}")
        
        if len(productos) > limite:
            print(f"... y {len(productos) - limite} productos más")
    
    def actualizar_stock(self, nombre_producto, nuevo_stock):
        """Actualizar stock de producto"""
        productos = self.cargar_productos()
        for producto in productos:
            if producto['PRODUCTO'].lower() == nombre_producto.lower():
                self.crear_backup()
                producto['STOK ACTUAL'] = nuevo_stock
                self.guardar_productos(productos)
                print(f"✅ Stock de '{nombre_producto}' actualizado a {nuevo_stock}")
                return
        print(f"❌ Producto '{nombre_producto}' no encontrado")

# Funciones de utilidad para uso directo
def agregar_producto_rapido():
    """Agregar producto con prompts interactivos"""
    gestor = GestorCatalogo()
    
    print("\n🆕 AGREGAR NUEVO PRODUCTO")
    print("=" * 40)
    
    producto_data = {
        'nombre': input("Nombre del producto: "),
        'descripcion': input("Descripción: "),
        'categoria': input("Categoría: "),
        'stock_actual': int(input("Stock actual: ") or 0),
        'precio_venta': int(input("Precio de venta: ") or 0),
        'costo': int(input("Costo: ") or 0),
        'proveedor': input("Proveedor: "),
        'observaciones': input("Observaciones (opcional): ")
    }
    
    gestor.agregar_producto(producto_data)

def buscar_producto_interactivo():
    """Buscar producto interactivamente"""
    gestor = GestorCatalogo()
    
    termino = input("🔍 Buscar producto: ")
    resultados = gestor.buscar_producto(termino)
    
    if resultados:
        print(f"\n📋 Encontrados {len(resultados)} resultados:")
        for i, (indice, producto) in enumerate(resultados):
            precio = f"${producto['PRECIO DE VENTA']:,}"
            print(f"{indice:3d}. {producto['PRODUCTO']} - {precio}")
    else:
        print("❌ No se encontraron productos")

if __name__ == "__main__":
    gestor = GestorCatalogo()
    
    if len(sys.argv) < 2:
        print("🛍️ GESTOR DE CATÁLOGO LILUTECNO")
        print("=" * 40)
        print("Opciones disponibles:")
        print("  python scripts_gestion_catalogo.py listar")
        print("  python scripts_gestion_catalogo.py agregar")
        print("  python scripts_gestion_catalogo.py buscar")
        print("  python scripts_gestion_catalogo.py stock [producto] [cantidad]")
        sys.exit(1)
    
    comando = sys.argv[1].lower()
    
    if comando == "listar":
        limite = int(sys.argv[2]) if len(sys.argv) > 2 else 20
        gestor.listar_productos(limite)
    
    elif comando == "agregar":
        agregar_producto_rapido()
    
    elif comando == "buscar":
        buscar_producto_interactivo()
    
    elif comando == "stock":
        if len(sys.argv) >= 4:
            producto = sys.argv[2]
            stock = int(sys.argv[3])
            gestor.actualizar_stock(producto, stock)
        else:
            print("❌ Uso: python scripts_gestion_catalogo.py stock [nombre_producto] [cantidad]")
    
    else:
        print(f"❌ Comando '{comando}' no reconocido")
