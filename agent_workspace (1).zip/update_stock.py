import json
import random

# Leer el archivo JSON
with open('/workspace/lilutecno-catalogo/public/productos_catalogo.json', 'r', encoding='utf-8') as f:
    productos = json.load(f)

# Actualizar el stock de algunos productos (primeros 50 productos)
for i, producto in enumerate(productos[:50]):
    # Dar stock aleatorio entre 1 y 15 unidades
    nuevo_stock = random.randint(1, 15)
    producto["STOK ACTUAL"] = nuevo_stock
    print(f"Producto {i+1}: {producto['PRODUCTO'][:50]}... - Stock: {nuevo_stock}")

# Guardar el archivo actualizado
with open('/workspace/lilutecno-catalogo/public/productos_catalogo.json', 'w', encoding='utf-8') as f:
    json.dump(productos, f, ensure_ascii=False, indent=2)

print(f"\n✅ Actualizado el stock de los primeros 50 productos")
print(f"Total de productos: {len(productos)}")
