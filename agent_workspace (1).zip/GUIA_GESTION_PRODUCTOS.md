# 🛍️ GUÍA COMPLETA: Cómo Agregar y Editar Productos - LiluTecno

## 🎯 RESUMEN DE OPCIONES

Tienes **3 formas principales** de gestionar tu catálogo de productos:

1. **🌐 Panel Web de Administración** (RECOMENDADO)
2. **📊 Editar Archivo Excel**
3. **💻 Scripts Automáticos**

---

## 🌐 OPCIÓN 1: PANEL WEB DE ADMINISTRACIÓN

### ✅ **LA MÁS FÁCIL Y RECOMENDADA**

**🔗 Acceso**: https://qflk5rnxkq.space.minimax.io/admin  
**👤 Usuario**: Administrador  
**🔒 Contraseña**: `lilutecno2024`

### 📱 **Qué puedes hacer:**

#### ➕ **AGREGAR NUEVO PRODUCTO**
1. Clic en **"Agregar Producto"**
2. Llenar formulario:
   - Nombre del producto
   - Descripción detallada
   - Categoría (seleccionar de lista)
   - Stock disponible
   - Precio de venta
   - Costo de compra
   - Proveedor
   - Subir imagen (opcional)
3. **Guardar** → ¡Aparece inmediatamente en el catálogo!

#### ✏️ **EDITAR PRODUCTO EXISTENTE**
1. **Buscar** el producto en la tabla
2. Clic en **ícono de editar** (✏️)
3. **Modificar** los campos que necesites
4. **Guardar cambios**

#### 🗑️ **ELIMINAR PRODUCTOS**
1. **Seleccionar** uno o varios productos
2. Clic en **"Eliminar"**
3. **Confirmar** la eliminación

#### 🔍 **BUSCAR Y FILTRAR**
- **Buscar por nombre**: Escribe en el buscador
- **Filtrar por categoría**: Dropdown de categorías
- **Filtrar por stock**: Disponibles, agotados, stock bajo
- **Ordenar**: Por nombre, precio, stock, etc.

---

## 📊 OPCIÓN 2: EDITAR ARCHIVO EXCEL

### 📝 **Para quienes prefieren Excel:**

#### **Pasos para actualizar:**
1. **Abrir** tu archivo `INVENTARIO LiluTecno (1).xlsx`
2. **Ir a la hoja "Inventario"**
3. **Agregar nueva fila** o **editar existente**:

| PRODUCTO | DESCRIPCION | CATEGORIA | STOCK ACTUAL | PRECIO DE VENTA | COSTO | PROVEEDOR |
|----------|-------------|-----------|--------------|-----------------|--------|-----------|
| Nuevo TV 32" | TV Smart Android 32 pulgadas | TELEVISOR | 10 | 650000 | 450000 | Samsung |

4. **Guardar el archivo**
5. **Subir al panel web** (función de importar preparada)

#### **📋 Columnas importantes:**
- **PRODUCTO**: Nombre del producto (requerido)
- **DESCRIPCION**: Descripción detallada
- **CATEGORIA**: Categoría del producto
- **STOCK ACTUAL**: Cantidad disponible
- **PRECIO DE VENTA**: Precio para el cliente
- **COSTO**: Tu costo de compra
- **PROVEEDOR**: Nombre del proveedor

---

## 💻 OPCIÓN 3: SCRIPTS AUTOMÁTICOS

### ⚡ **Para usuarios avanzados:**

#### **📋 Listar productos actuales:**
```bash
python scripts_gestion_catalogo.py listar
```

#### **➕ Agregar producto nuevo:**
```bash
python scripts_gestion_catalogo.py agregar
```
Te pedirá información paso a paso.

#### **🔍 Buscar productos:**
```bash
python scripts_gestion_catalogo.py buscar
```

#### **📦 Actualizar stock:**
```bash
python scripts_gestion_catalogo.py stock "TELEVISOR 65" 15
```

---

## 🖼️ GESTIÓN DE IMÁGENES

### **Para agregar imágenes a productos:**

#### **Opción A: Panel Web**
1. En el formulario de producto
2. **"Subir imagen"** o arrastrar archivo
3. **Vista previa automática**
4. **Guardar** → Imagen se optimiza automáticamente

#### **Opción B: Manual**
1. **Subir imagen** a carpeta `imagenes_productos/`
2. **Nombrar archivo**: `producto_nuevo_123.jpg`
3. El sistema la detectará automáticamente

---

## 📊 CATEGORÍAS DISPONIBLES

Categorías existentes en tu catálogo:
- TELEVISOR
- ENTRETENIMIENTO
- ACCESORIOS
- AUDIO
- GAMING
- CARGADORES
- CELULARES
- TABLETS
- COMPUTADORES
- SMART HOME
- Y más...

---

## ⚡ ACTUALIZACIÓN AUTOMÁTICA

### **¡IMPORTANTE!**
- **Cambios inmediatos**: Todo lo que hagas se refleja al instante
- **Backup automático**: Se crea respaldo antes de cambios
- **Sincronización**: El catálogo público se actualiza automáticamente
- **WhatsApp integrado**: Los nuevos productos ya tienen botón de WhatsApp

---

## 🚀 RECOMENDACIONES

### **✅ MEJOR PRÁCTICA:**
1. **Usar el Panel Web** para gestión diaria
2. **Mantener Excel actualizado** como respaldo
3. **Subir imágenes de calidad** para mejor conversión
4. **Revisar precios regularmente** para mantener márgenes
5. **Actualizar stock** cuando vendas productos

### **📱 DESDE EL CELULAR:**
- El **panel web funciona perfecto** en móviles
- Puedes **agregar productos** desde cualquier lugar
- **Actualizar stock** mientras vendes
- **Editar precios** sobre la marcha

---

## 🆘 SOPORTE

### **Si necesitas ayuda:**
1. **Panel Web**: Todo es intuitivo con botones claros
2. **Excel**: Mantén el formato de columnas original
3. **Scripts**: Ejecutar con `python scripts_gestion_catalogo.py`

### **🔄 Restaurar desde backup:**
Los backups se guardan automáticamente en `backups_catalogo/`

---

## 🎯 PRÓXIMOS PASOS

1. **Probar el panel web** - Es la forma más fácil
2. **Agregar algunos productos nuevos** para familiarizarte
3. **Actualizar stock** de productos existentes
4. **Subir imágenes** para productos que no las tengan

¡Tu catálogo está **100% listo** para crecer y generar más ventas! 🚀
