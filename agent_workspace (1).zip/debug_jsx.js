const fs = require('fs');

// Leer el archivo
const content = fs.readFileSync('/workspace/lilutecno-catalogo/src/components/ProductModal.tsx', 'utf8');

// Contar etiquetas
const motionDivOpening = (content.match(/<motion\.div/g) || []).length;
const motionDivClosing = (content.match(/<\/motion\.div>/g) || []).length;
const divOpening = (content.match(/<div/g) || []).length;
const divClosing = (content.match(/<\/div>/g) || []).length;

console.log('Motion.div opening tags:', motionDivOpening);
console.log('Motion.div closing tags:', motionDivClosing);
console.log('Regular div opening tags:', divOpening);
console.log('Regular div closing tags:', divClosing);
console.log('Total opening tags:', motionDivOpening + divOpening);
console.log('Total closing tags:', motionDivClosing + divClosing);

// Buscar líneas con motion.div
const lines = content.split('\n');
lines.forEach((line, index) => {
  if (line.includes('motion.div')) {
    console.log(`Line ${index + 1}: ${line.trim()}`);
  }
});
