import pandas as pd
import json
import os

# Crear directorios si no existen
os.makedirs('data', exist_ok=True)

try:
    # Leer el archivo Excel
    file_path = 'user_input_files/INVENTARIO LiluTecno (1).xlsx'
    
    # Intentar leer las diferentes hojas si las hay
    excel_file = pd.ExcelFile(file_path)
    print('Hojas disponibles:', excel_file.sheet_names)
    
    # Leer la hoja de Inventario específicamente
    df = pd.read_excel(file_path, sheet_name='Inventario')
    
    print('\nColumnas disponibles:')
    print(list(df.columns))
    
    print('\nPrimeras 5 filas:')
    print(df.head())
    
    print('\nInformación del dataset:')
    print(f'Total de productos: {len(df)}')
    print(f'Columnas: {df.shape[1]}')
    
    # Limpiar datos NaN y convertir a string
    df_clean = df.fillna('')
    
    # Guardar datos como JSON para usar en la web
    productos_json = df_clean.to_dict('records')
    
    with open('data/productos_catalogo.json', 'w', encoding='utf-8') as f:
        json.dump(productos_json, f, indent=2, ensure_ascii=False)
    
    print('\nDatos guardados en data/productos_catalogo.json')
    
    # Mostrar estructura de un producto ejemplo
    if len(productos_json) > 0:
        print('\nEjemplo de producto:')
        print(json.dumps(productos_json[0], indent=2, ensure_ascii=False))
    
except Exception as e:
    print(f'Error al leer el archivo: {e}')
    import traceback
    traceback.print_exc()
