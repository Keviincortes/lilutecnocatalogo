import pandas as pd
import json
import re

# Leer los datos del catálogo
df = pd.read_excel('user_input_files/INVENTARIO LiluTecno (1).xlsx', sheet_name='Inventario')

# Limpiar datos
df_clean = df.fillna('')

# Función para generar búsquedas de imágenes
def generar_busquedas_imagenes(df, limite=50):
    busquedas = []
    
    for i, row in df.head(limite).iterrows():
        producto = str(row['PRODUCTO']).strip()
        categoria = str(row['CATEGORIA']).strip()
        
        if producto and producto != '':
            # Limpiar el nombre del producto para búsqueda
            producto_limpio = re.sub(r'[^\w\s]', ' ', producto)
            producto_limpio = re.sub(r'\s+', ' ', producto_limpio).strip()
            
            # Crear query de búsqueda más específica
            query = f"{producto_limpio} {categoria} tecnologia"
            
            # Generar nombre de archivo seguro
            nombre_archivo = re.sub(r'[^\w\s-]', '', producto_limpio)
            nombre_archivo = re.sub(r'\s+', '_', nombre_archivo).lower()
            
            busquedas.append({
                "query": query,
                "output_file": f"imagenes_productos/{nombre_archivo}_{i+1}.jpg"
            })
    
    return busquedas

# Generar búsquedas para los primeros 50 productos
print("Generando búsquedas de imágenes para productos...")
busquedas = generar_busquedas_imagenes(df_clean, 50)

print(f"Se generarán {len(busquedas)} búsquedas de imágenes")
for i, busqueda in enumerate(busquedas[:5]):
    print(f"{i+1}. Query: {busqueda['query']}")
    print(f"   Archivo: {busqueda['output_file']}")

# Guardar las búsquedas para usar
with open('data/busquedas_imagenes.json', 'w', encoding='utf-8') as f:
    json.dump(busquedas, f, indent=2, ensure_ascii=False)

print("\nBúsquedas guardadas en data/busquedas_imagenes.json")
