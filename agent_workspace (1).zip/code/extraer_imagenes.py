import pandas as pd
import openpyxl
from openpyxl_image_loader import SheetImageLoader
import os
import json

# Crear directorios
os.makedirs('imagenes_productos', exist_ok=True)
os.makedirs('data', exist_ok=True)

try:
    # Abrir el archivo Excel con openpyxl para extraer imágenes
    wb = openpyxl.load_workbook('user_input_files/INVENTARIO LiluTecno (1).xlsx')
    
    # Intentar extraer imágenes de la hoja Inventario
    if 'Inventario' in wb.sheetnames:
        sheet = wb['Inventario']
        
        # Verificar si hay imágenes en la hoja
        if hasattr(sheet, '_images') and len(sheet._images) > 0:
            print(f"Encontradas {len(sheet._images)} imágenes en la hoja")
            
            # Extraer imágenes
            for i, image in enumerate(sheet._images):
                try:
                    # Guardar imagen
                    image_path = f'imagenes_productos/producto_{i+1}.{image.format.lower()}'
                    with open(image_path, 'wb') as f:
                        f.write(image._data())
                    print(f"Imagen guardada: {image_path}")
                except Exception as e:
                    print(f"Error guardando imagen {i}: {e}")
        else:
            print("No se encontraron imágenes incrustadas en la hoja")
    
    # También revisar las otras hojas
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        if hasattr(sheet, '_images') and len(sheet._images) > 0:
            print(f"Hoja '{sheet_name}' tiene {len(sheet._images)} imágenes")
    
    # Leer los datos normalmente
    df = pd.read_excel('user_input_files/INVENTARIO LiluTecno (1).xlsx', sheet_name='Inventario')
    
    print("\nInformación de las columnas de imágenes:")
    for col in ['IMAGEN 1', 'IMAGEN 2', 'IMAGEN 3', 'IMAGEN 4', 'IMAGEN 5']:
        if col in df.columns:
            unique_values = df[col].dropna().unique()
            print(f"{col}: {len(unique_values)} valores únicos")
            if len(unique_values) > 0:
                print(f"  Ejemplos: {list(unique_values[:5])}")

except Exception as e:
    print(f"Error procesando archivo: {e}")
    import traceback
    traceback.print_exc()
