import pandas as pd
import json
import os
import re

# Leer datos del catálogo
df = pd.read_excel('user_input_files/INVENTARIO LiluTecno (1).xlsx', sheet_name='Inventario')
df_clean = df.fillna('')

# Función para encontrar la imagen correspondiente al producto
def encontrar_imagen_producto(producto, indice):
    # Limpiar nombre del producto
    producto_limpio = re.sub(r'[^\w\s-]', '', str(producto))
    producto_limpio = re.sub(r'\s+', '_', producto_limpio).lower()
    
    # Posibles nombres de archivo
    posibles_nombres = [
        f"imagenes_productos/{producto_limpio}_{indice+1}.jpg",
        f"imagenes_productos/{producto_limpio.replace('_', '')[:20]}_{indice+1}.jpg"
    ]
    
    # Buscar archivo que exista
    for nombre in posibles_nombres:
        if os.path.exists(nombre):
            return nombre
    
    # Mapeo manual para productos específicos
    mapeo_manual = {
        0: "imagenes_productos/televisor_65_smart_tv_1.jpg",  # TELEVISOR 65"
        1: "imagenes_productos/televisor_55_smart_tv_2.jpg",  # TELEVISOR 55" 
        2: "imagenes_productos/televisor_43_smart_tv_3.jpg",  # TELEVISOR 43"
        3: "imagenes_productos/televisor_19_4.jpg",           # TELEVISOR 19"
        4: "imagenes_productos/mini_proyector_led_300_5.jpg", # MINI PROYECTOR
        5: "imagenes_productos/proyector_hcs_350_pro_6.jpg",  # PROYECTOR HCS
    }
    
    if indice in mapeo_manual:
        if os.path.exists(mapeo_manual[indice]):
            return mapeo_manual[indice]
    
    # Mapeo por categorías comunes
    producto_str = str(producto).upper()
    if "TELEVISOR" in producto_str or "TV" in producto_str:
        if "65" in producto_str:
            return "imagenes_productos/televisor_65_smart_tv_1.jpg"
        elif "55" in producto_str:
            return "imagenes_productos/televisor_55_smart_tv_2.jpg"
        elif "43" in producto_str:
            return "imagenes_productos/televisor_43_smart_tv_3.jpg"
        else:
            return "imagenes_productos/televisor_19_4.jpg"
    elif "PROYECTOR" in producto_str:
        return "imagenes_productos/mini_proyector_led_300_5.jpg"
    elif "MOUSE" in producto_str or "RATON" in producto_str:
        return "imagenes_productos/mouse_gaming_8.jpg"
    elif "TECLADO" in producto_str or "KEYBOARD" in producto_str:
        return "imagenes_productos/teclado_gaming_9.jpg"
    elif "AUDIFONOS" in producto_str or "AURICULARES" in producto_str:
        return "imagenes_productos/audifonos_gaming_10.jpg"
    elif "ALTAVOZ" in producto_str or "PARLANTE" in producto_str:
        return "imagenes_productos/altavoz_bluetooth_15.jpg"
    elif "CABLE USB" in producto_str:
        return "imagenes_productos/cable_usb_c_11.jpg"
    elif "CABLE HDMI" in producto_str:
        return "imagenes_productos/cable_hdmi_12.jpg"
    elif "CARGADOR" in producto_str or "POWER BANK" in producto_str:
        return "imagenes_productos/cargador_portatil_13.jpg"
    elif "WEBCAM" in producto_str or "CAMARA" in producto_str:
        return "imagenes_productos/webcam_hd_16.jpg"
    elif "MICROFONO" in producto_str:
        return "imagenes_productos/microfono_gaming_17.jpg"
    elif "SOPORTE" in producto_str:
        return "imagenes_productos/soporte_celular_18.jpg"
    elif "WIFI" in producto_str or "ADAPTADOR" in producto_str:
        return "imagenes_productos/adaptador_wifi_19.jpg"
    elif "HUB" in producto_str:
        return "imagenes_productos/hub_usb_20.jpg"
    
    # Imagen por defecto para productos sin imagen específica
    return "imagenes_productos/televisor_65_smart_tv_1.jpg"

# Verificar qué imágenes están disponibles
print("Imágenes disponibles:")
imagenes_disponibles = []
if os.path.exists('imagenes_productos'):
    for archivo in os.listdir('imagenes_productos'):
        if archivo.endswith('.jpg'):
            imagenes_disponibles.append(f"imagenes_productos/{archivo}")
            print(f"  {archivo}")

print(f"\nTotal de imágenes disponibles: {len(imagenes_disponibles)}")

# Actualizar datos del catálogo con imágenes
productos_actualizados = []

for i, row in df_clean.iterrows():
    producto_dict = row.to_dict()
    
    # Agregar imagen principal
    imagen_path = encontrar_imagen_producto(row['PRODUCTO'], i)
    producto_dict['imagen_principal'] = imagen_path
    
    # Agregar múltiples imágenes (usar la misma por ahora)
    producto_dict['imagenes'] = [imagen_path]
    
    productos_actualizados.append(producto_dict)

# Guardar datos actualizados
with open('data/productos_con_imagenes.json', 'w', encoding='utf-8') as f:
    json.dump(productos_actualizados, f, indent=2, ensure_ascii=False)

print(f"\nDatos actualizados guardados en data/productos_con_imagenes.json")
print(f"Total de productos procesados: {len(productos_actualizados)}")

# Mostrar algunos ejemplos
print("\nEjemplos de productos con imágenes:")
for i, producto in enumerate(productos_actualizados[:5]):
    print(f"{i+1}. {producto['PRODUCTO']}")
    print(f"   Imagen: {producto['imagen_principal']}")
    print(f"   Precio: ${producto['PRECIO DE VENTA']:,}")
    print()
