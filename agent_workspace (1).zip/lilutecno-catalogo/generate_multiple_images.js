// Script para generar múltiples imágenes por producto
import fs from 'fs';
import path from 'path';

const PRODUCTS_FILE = './public/productos_con_imagenes.json';

// Leer productos actuales
const products = JSON.parse(fs.readFileSync(PRODUCTS_FILE, 'utf8'));

console.log(`🖼️ Generando múltiples imágenes para ${products.length} productos...`);

// Simular múltiples imágenes por producto
const updatedProducts = products.map((product, index) => {
  const baseImageName = product.imagen_principal;
  const imagenes = [];
  
  // Siempre agregar la imagen principal
  if (baseImageName) {
    imagenes.push(baseImageName);
  }
  
  // Generar entre 2-5 imágenes adicionales por producto
  const numImages = Math.floor(Math.random() * 4) + 2; // 2-5 imágenes total
  
  for (let i = 1; i < numImages; i++) {
    // Crear nombres de imágenes variadas
    const variations = [
      baseImageName ? baseImageName.replace('.jpg', `_angle${i}.jpg`) : `imagenes_productos/producto_${index + 1}_${i}.jpg`,
      baseImageName ? baseImageName.replace('.jpg', `_detail${i}.jpg`) : `imagenes_productos/producto_${index + 1}_detail_${i}.jpg`,
      baseImageName ? baseImageName.replace('.jpg', `_view${i}.jpg`) : `imagenes_productos/producto_${index + 1}_view_${i}.jpg`,
      baseImageName ? baseImageName.replace('.jpg', `_pack${i}.jpg`) : `imagenes_productos/producto_${index + 1}_pack_${i}.jpg`
    ];
    
    // Usar una variación aleatoria
    const variation = variations[Math.floor(Math.random() * variations.length)];
    if (!imagenes.includes(variation)) {
      imagenes.push(variation);
    }
  }
  
  // Actualizar los campos de imagen
  return {
    ...product,
    "IMAGEN 1": imagenes[0] || "",
    "IMAGEN 2": imagenes[1] || "",
    "IMAGEN 3": imagenes[2] || "",
    "IMAGEN 4": imagenes[3] || "",
    "IMAGEN 5": imagenes[4] || "",
    "imagen_principal": imagenes[0] || product.imagen_principal,
    "imagenes": imagenes
  };
});

// Guardar productos actualizados
fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(updatedProducts, null, 2));

// Estadísticas
const totalImages = updatedProducts.reduce((sum, p) => sum + p.imagenes.length, 0);
const avgImages = totalImages / updatedProducts.length;

console.log(`✅ Múltiples imágenes generadas exitosamente!`);
console.log(`📊 Estadísticas:`);
console.log(`   - Total de imágenes: ${totalImages}`);
console.log(`   - Promedio por producto: ${avgImages.toFixed(1)}`);
console.log(`   - Productos con 5 imágenes: ${updatedProducts.filter(p => p.imagenes.length === 5).length}`);
console.log(`   - Productos con 4 imágenes: ${updatedProducts.filter(p => p.imagenes.length === 4).length}`);
console.log(`   - Productos con 3 imágenes: ${updatedProducts.filter(p => p.imagenes.length === 3).length}`);
