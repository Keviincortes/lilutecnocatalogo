import { Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import App from './App';
import AdminLogin from './components/admin/AdminLogin';
import AdminLayout from './components/admin/AdminLayout';
import Dashboard from './components/admin/Dashboard';
import ProductsManagementImproved from './components/admin/ProductsManagementImproved';

// Componente para proteger rutas del admin
const ProtectedAdminRoute = ({ children, currentPage }: { children: React.ReactNode; currentPage: string }) => {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <AdminLogin />;
  }
  
  return (
    <AdminLayout currentPage={currentPage}>
      {children}
    </AdminLayout>
  );
};

// Componente para crear páginas del admin de forma más limpia
const AdminPage = ({ children, pageId }: { children: React.ReactNode; pageId: string }) => (
  <ProtectedAdminRoute currentPage={pageId}>
    {children}
  </ProtectedAdminRoute>
);

// Componentes temporales para las páginas que no hemos implementado aún
const CategoriesManagement = () => (
  <div className="space-y-6">
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Gestión de Categorías</h2>
      <p className="text-gray-600 mb-6">Esta funcionalidad estará disponible próximamente.</p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-700 text-sm">
          🚧 En desarrollo: Crear, editar y eliminar categorías de productos
        </p>
      </div>
    </div>
  </div>
);

const ImagesManagement = () => (
  <div className="space-y-6">
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Gestión de Imágenes</h2>
      <p className="text-gray-600 mb-6">Esta funcionalidad estará disponible próximamente.</p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-700 text-sm">
          🚧 En desarrollo: Subir, organizar y gestionar imágenes de productos
        </p>
      </div>
    </div>
  </div>
);

const Analytics = () => (
  <div className="space-y-6">
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Estadísticas y Análisis</h2>
      <p className="text-gray-600 mb-6">Esta funcionalidad estará disponible próximamente.</p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-700 text-sm">
          🚧 En desarrollo: Reportes de ventas, productos más vendidos y métricas
        </p>
      </div>
    </div>
  </div>
);

const Settings = () => (
  <div className="space-y-6">
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Configuración</h2>
      <p className="text-gray-600 mb-6">Esta funcionalidad estará disponible próximamente.</p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-700 text-sm">
          🚧 En desarrollo: Configurar datos de la empresa, WhatsApp, etc.
        </p>
      </div>
    </div>
  </div>
);

const Router = () => {
  return (
    <AuthProvider>
      <Routes>
        {/* Ruta principal del catálogo */}
        <Route path="/" element={<App />} />
        
        {/* Rutas del panel de administración */}
        <Route path="/admin" element={
          <AdminPage pageId="dashboard">
            <Dashboard />
          </AdminPage>
        } />
        
        <Route path="/admin/productos" element={
          <AdminPage pageId="products">
            <ProductsManagementImproved />
          </AdminPage>
        } />
        
        <Route path="/admin/categorias" element={
          <AdminPage pageId="categories">
            <CategoriesManagement />
          </AdminPage>
        } />
        
        <Route path="/admin/imagenes" element={
          <AdminPage pageId="images">
            <ImagesManagement />
          </AdminPage>
        } />
        
        <Route path="/admin/estadisticas" element={
          <AdminPage pageId="analytics">
            <Analytics />
          </AdminPage>
        } />
        
        <Route path="/admin/configuracion" element={
          <AdminPage pageId="settings">
            <Settings />
          </AdminPage>
        } />

        {/* Ruta de login del admin (si acceden directamente) */}
        <Route path="/admin/login" element={<AdminLogin />} />
        
        {/* Ruta 404 - redirigir al catálogo */}
        <Route path="*" element={<App />} />
      </Routes>
    </AuthProvider>
  );
};

export default Router;
