import { useState, useEffect } from 'react'
import { Product, FilterState } from './types/Product'
import { CartProvider } from './contexts/CartContext'
import { WishlistProvider } from './contexts/WishlistContext'
import Header from './components/Header'
import FilterPanel from './components/FilterPanel'
import MobileFilters from './components/MobileFilters'
import ProductGrid from './components/ProductGrid'
import ProductModal from './components/ProductModal'
import Cart from './components/Cart'
import LoadingSpinner from './components/LoadingSpinner'
import WhatsAppButton from './components/ui/WhatsAppButton'
import './App.css'

function App() {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false)
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    category: '',
    priceRange: [0, 2000000],
    inStock: null
  })

  // Cargar productos desde el archivo JSON con imágenes
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true)
        const response = await fetch('/productos_con_imagenes.json')
        if (!response.ok) {
          throw new Error('No se pudieron cargar los productos')
        }
        const data = await response.json()
        setProducts(data)
        setFilteredProducts(data)
        setError(null)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido')
      } finally {
        setLoading(false)
      }
    }

    loadProducts()
  }, [])

  // Filtrar productos cuando cambian los filtros
  useEffect(() => {
    let filtered = [...products]

    // Filtro de búsqueda
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase()
      filtered = filtered.filter(product =>
        product.PRODUCTO.toLowerCase().includes(searchTerm) ||
        product.DESCRICION.toLowerCase().includes(searchTerm) ||
        product.CATEGORIA.toLowerCase().includes(searchTerm)
      )
    }

    // Filtro de categoría
    if (filters.category) {
      filtered = filtered.filter(product => product.CATEGORIA === filters.category)
    }

    // Filtro de rango de precios
    filtered = filtered.filter(product => 
      product["PRECIO DE VENTA"] >= filters.priceRange[0] && 
      product["PRECIO DE VENTA"] <= filters.priceRange[1]
    )

    // Filtro de stock
    if (filters.inStock !== null) {
      if (filters.inStock) {
        filtered = filtered.filter(product => product["STOK ACTUAL"] > 0)
      } else {
        filtered = filtered.filter(product => product["STOK ACTUAL"] === 0)
      }
    }

    setFilteredProducts(filtered)
  }, [products, filters])

  const handleFilterChange = (newFilters: Partial<FilterState>) => {
    setFilters(prev => ({ ...prev, ...newFilters }))
  }

  const handleOpenCart = () => {
    setIsCartOpen(true)
  }

  const handleCloseCart = () => {
    setIsCartOpen(false)
  }

  const handleOpenMobileFilters = () => {
    setIsMobileFiltersOpen(true)
  }

  const handleCloseMobileFilters = () => {
    setIsMobileFiltersOpen(false)
  }

  // Obtener categorías únicas
  const categories = [...new Set(products.map(product => product.CATEGORIA))]

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center">
        <div className="text-center bg-white p-8 rounded-2xl shadow-2xl">
          <h2 className="text-3xl font-bold text-red-600 mb-4">🚨 Error al cargar el catálogo</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-6 py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-xl hover:from-red-600 hover:to-orange-600 transition-all font-bold shadow-lg"
          >
            🔄 Reintentar
          </button>
        </div>
      </div>
    )
  }

  return (
    <CartProvider>
      <WishlistProvider>
        <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
          <Header 
            productCount={filteredProducts.length} 
            totalCount={products.length}
            onOpenCart={handleOpenCart}
            onOpenFilters={handleOpenMobileFilters}
          />
          
          <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
            <div className="flex flex-col lg:flex-row gap-4 lg:gap-8">
              {/* Panel de filtros - Solo en escritorio */}
              <div className="hidden lg:block lg:w-80 flex-shrink-0">
                <FilterPanel 
                  products={products}
                  filters={filters}
                  onFilterChange={handleFilterChange}
                />
              </div>

              {/* Grid de productos */}
              <div className="flex-1">
                <ProductGrid 
                  products={filteredProducts}
                  onProductClick={setSelectedProduct}
                />
              </div>
            </div>
          </div>

          {/* Filtros móviles */}
          <MobileFilters 
            filters={filters}
            onFiltersChange={setFilters}
            categories={categories}
            isOpen={isMobileFiltersOpen}
            onToggle={handleCloseMobileFilters}
          />

          {/* Modal de detalles del producto */}
          {selectedProduct && (
            <ProductModal 
              product={selectedProduct}
              isOpen={true}
              onClose={() => setSelectedProduct(null)}
            />
          )}

          {/* Carrito de compras */}
          <Cart 
            isOpen={isCartOpen}
            onClose={handleCloseCart}
          />

          {/* Botón flotante de WhatsApp */}
          <WhatsAppButton
            message="¡Hola! 👋 Me interesa conocer más sobre sus productos tecnológicos. ¿Podrían ayudarme con información y precios actualizados? 

🛍️ Estoy buscando:
• Información sobre productos disponibles
• Precios y ofertas actuales
• Condiciones de envío
• Métodos de pago

¡Gracias por su atención! 😊

*LiluTecno - Su tecnología, nuestra pasión* 🚀"
            variant="floating"
          />
        </div>
      </WishlistProvider>
    </CartProvider>
  )
}

export default App
