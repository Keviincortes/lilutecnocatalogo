import { useState, useEffect } from 'react'

interface UseModalReturn {
  isOpen: boolean
  openModal: () => void
  closeModal: () => void
}

export const useModal = (): UseModalReturn => {
  const [isOpen, setIsOpen] = useState(false)

  const openModal = () => {
    setIsOpen(true)
    // Prevenir scroll del body
    document.body.classList.add('modal-open')
  }

  const closeModal = () => {
    setIsOpen(false)
    // Restaurar scroll del body
    document.body.classList.remove('modal-open')
  }

  // Cerrar modal con tecla Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        closeModal()
      }
    }

    if (isOpen) {
      document.addEventListener('keydown', handleEscape)
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
    }
  }, [isOpen])

  // Cleanup al desmontar el componente
  useEffect(() => {
    return () => {
      document.body.classList.remove('modal-open')
    }
  }, [])

  return {
    isOpen,
    openModal,
    closeModal
  }
}

export default useModal
