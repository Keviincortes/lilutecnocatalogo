import { openWhatsApp } from '../utils/whatsapp'

interface UseWhatsAppReturn {
  sendToWhatsApp: (message: string) => void
  isSupported: boolean
}

export const useWhatsApp = (): UseWhatsAppReturn => {
  const sendToWhatsApp = (message: string) => {
    try {
      openWhatsApp(message)
    } catch (error) {
      console.error('Error al abrir WhatsApp:', error)
      // Fallback: mostrar alerta con el mensaje
      alert(`No se pudo abrir WhatsApp automáticamente. Copia este mensaje:\n\n${message}`)
    }
  }

  // Verificar si WhatsApp es soportado en el dispositivo/navegador
  const isSupported = typeof window !== 'undefined' && 
                      (window.navigator.userAgent.includes('WhatsApp') || 
                       /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(window.navigator.userAgent) ||
                       true) // Siempre true porque funciona en desktop también

  return {
    sendToWhatsApp,
    isSupported
  }
}

export default useWhatsApp
