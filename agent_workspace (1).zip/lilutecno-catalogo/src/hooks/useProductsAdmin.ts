import { useState, useEffect, useCallback } from 'react';
import { Product } from '../types/Product';

interface UseProductsAdminReturn {
  products: Product[];
  loading: boolean;
  error: string | null;
  addProduct: (productData: any) => Promise<void>;
  updateProduct: (productId: string, productData: any) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  saveToFile: () => Promise<void>;
  refreshProducts: () => Promise<void>;
}

export const useProductsAdmin = (): UseProductsAdminReturn => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cargar productos iniciales
  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/productos_con_imagenes.json');
      if (!response.ok) {
        throw new Error('Error al cargar productos');
      }
      
      const data = await response.json();
      setProducts(data);
    } catch (err) {
      console.error('Error loading products:', err);
      setError('Error al cargar productos');
      
      // Fallback: cargar desde localStorage
      const saved = localStorage.getItem('lilutecno_products_admin');
      if (saved) {
        setProducts(JSON.parse(saved));
      }
    } finally {
      setLoading(false);
    }
  }, []);

  // Cargar productos al montar el componente
  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  // Guardar productos en localStorage automáticamente
  useEffect(() => {
    if (products.length > 0) {
      localStorage.setItem('lilutecno_products_admin', JSON.stringify(products));
    }
  }, [products]);

  // Agregar nuevo producto
  const addProduct = useCallback(async (productData: any) => {
    try {
      const newProduct: Product = {
        'Unnamed: 0': `new_${Date.now()}`,
        PRODUCTO: productData.PRODUCTO,
        'IMAGEN 1': productData.imagenes[0] || '',
        'IMAGEN 2': productData.imagenes[1] || '',
        'IMAGEN 3': productData.imagenes[2] || '',
        'IMAGEN 4': productData.imagenes[3] || '',
        'IMAGEN 5': productData.imagenes[4] || '',
        DESCRICION: productData.DESCRICION,
        CATEGORIA: productData.CATEGORIA,
        'STOCK INICIAL': productData['STOK ACTUAL'],
        ENTRADAS: 0,
        SALIDAS: 0,
        'STOK ACTUAL': productData['STOK ACTUAL'],
        'PRECIO DE VENTA': productData['PRECIO DE VENTA'],
        COSTO: productData.COSTO,
        PROVEEDOR: productData.PROVEEDOR,
        OBSERVACIONES: productData.OBSERVACIONES,
        imagen_principal: productData.imagenes[0] || ''
      };

      setProducts(prev => [...prev, newProduct]);
    } catch (err) {
      console.error('Error adding product:', err);
      throw new Error('Error al agregar producto');
    }
  }, []);

  // Actualizar producto existente
  const updateProduct = useCallback(async (productId: string, productData: any) => {
    try {
      setProducts(prev => prev.map(product => {
        if (product['Unnamed: 0'] === productId || product.PRODUCTO === productId) {
          return {
            ...product,
            PRODUCTO: productData.PRODUCTO,
            'IMAGEN 1': productData.imagenes[0] || '',
            'IMAGEN 2': productData.imagenes[1] || '',
            'IMAGEN 3': productData.imagenes[2] || '',
            'IMAGEN 4': productData.imagenes[3] || '',
            'IMAGEN 5': productData.imagenes[4] || '',
            DESCRICION: productData.DESCRICION,
            CATEGORIA: productData.CATEGORIA,
            'STOK ACTUAL': productData['STOK ACTUAL'],
            'PRECIO DE VENTA': productData['PRECIO DE VENTA'],
            COSTO: productData.COSTO,
            PROVEEDOR: productData.PROVEEDOR,
            OBSERVACIONES: productData.OBSERVACIONES,
            imagen_principal: productData.imagenes[0] || ''
          };
        }
        return product;
      }));
    } catch (err) {
      console.error('Error updating product:', err);
      throw new Error('Error al actualizar producto');
    }
  }, []);

  // Eliminar producto
  const deleteProduct = useCallback(async (productId: string) => {
    try {
      setProducts(prev => prev.filter(product => 
        product['Unnamed: 0'] !== productId && product.PRODUCTO !== productId
      ));
    } catch (err) {
      console.error('Error deleting product:', err);
      throw new Error('Error al eliminar producto');
    }
  }, []);

  // Guardar en archivo (simulado)
  const saveToFile = useCallback(async () => {
    try {
      // En una aplicación real, esto haría una petición al servidor
      // Por ahora, solo guardamos en localStorage y mostramos confirmación
      localStorage.setItem('lilutecno_products_backup', JSON.stringify(products));
      
      // Simular descarga del archivo JSON
      const dataStr = JSON.stringify(products, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `productos_lilutecno_${new Date().toISOString().split('T')[0]}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
    } catch (err) {
      console.error('Error saving to file:', err);
      throw new Error('Error al guardar archivo');
    }
  }, [products]);

  // Refrescar productos
  const refreshProducts = useCallback(async () => {
    await loadProducts();
  }, [loadProducts]);

  return {
    products,
    loading,
    error,
    addProduct,
    updateProduct,
    deleteProduct,
    saveToFile,
    refreshProducts
  };
};

export default useProductsAdmin;
