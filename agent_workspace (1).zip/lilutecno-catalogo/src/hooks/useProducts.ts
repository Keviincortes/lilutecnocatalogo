import { useState, useEffect } from 'react';
import { Product } from '../types/Product';

export interface ProductsHook {
  products: Product[];
  loading: boolean;
  error: string | null;
  addProduct: (product: Omit<Product, 'Unnamed: 0'>) => Promise<boolean>;
  updateProduct: (productId: string, product: Partial<Product>) => Promise<boolean>;
  deleteProduct: (productId: string) => Promise<boolean>;
  refreshProducts: () => Promise<void>;
  categories: string[];
  providers: string[];
  getProductById: (id: string) => Product | undefined;
  duplicateProduct: (productId: string) => Promise<boolean>;
  importProducts: (products: Product[]) => Promise<boolean>;
  exportProducts: () => string;
}

const useProducts = (): ProductsHook => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Cargar productos al inicializar
  useEffect(() => {
    refreshProducts();
  }, []);

  const refreshProducts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/productos_con_imagenes.json');
      if (!response.ok) {
        throw new Error('No se pudieron cargar los productos');
      }
      const data = await response.json();
      setProducts(data);
      
      // Sincronizar con localStorage para cambios locales
      localStorage.setItem('lilutecno_products_cache', JSON.stringify(data));
      setError(null);
    } catch (err) {
      console.error('Error loading products:', err);
      
      // Intentar cargar desde localStorage como fallback
      const cached = localStorage.getItem('lilutecno_products_cache');
      if (cached) {
        try {
          const cachedProducts = JSON.parse(cached);
          setProducts(cachedProducts);
          setError('Usando datos en caché - algunos cambios pueden no estar sincronizados');
        } catch (parseErr) {
          setError('Error al cargar los productos');
          setProducts([]);
        }
      } else {
        setError('Error al cargar los productos');
        setProducts([]);
      }
    } finally {
      setLoading(false);
    }
  };

  const logAction = (action: string, productName: string, details?: any) => {
    const log = {
      timestamp: new Date().toISOString(),
      action,
      product: productName,
      details: details ? JSON.stringify(details) : undefined,
      user: 'admin'
    };
    const logs = JSON.parse(localStorage.getItem('lilutecno_admin_logs') || '[]');
    logs.push(log);
    localStorage.setItem('lilutecno_admin_logs', JSON.stringify(logs.slice(-100)));
  };

  const saveToCache = (updatedProducts: Product[]) => {
    localStorage.setItem('lilutecno_products_cache', JSON.stringify(updatedProducts));
    localStorage.setItem('lilutecno_products_last_update', new Date().toISOString());
  };

  const addProduct = async (productData: Omit<Product, 'Unnamed: 0'>): Promise<boolean> => {
    try {
      const newProduct: Product = {
        "Unnamed: 0": `new_${Date.now()}`,
        ...productData
      };

      const updatedProducts = [...products, newProduct];
      setProducts(updatedProducts);
      saveToCache(updatedProducts);
      
      logAction('ADD_PRODUCT', newProduct.PRODUCTO, { 
        price: newProduct["PRECIO DE VENTA"], 
        category: newProduct.CATEGORIA 
      });
      
      return true;
    } catch (err) {
      console.error('Error adding product:', err);
      return false;
    }
  };

  const updateProduct = async (productId: string, productData: Partial<Product>): Promise<boolean> => {
    try {
      const updatedProducts = products.map(product => 
        product.PRODUCTO === productId 
          ? { ...product, ...productData }
          : product
      );
      
      setProducts(updatedProducts);
      saveToCache(updatedProducts);
      
      logAction('UPDATE_PRODUCT', productId, productData);
      
      return true;
    } catch (err) {
      console.error('Error updating product:', err);
      return false;
    }
  };

  const deleteProduct = async (productId: string): Promise<boolean> => {
    try {
      const productToDelete = products.find(p => p.PRODUCTO === productId);
      const updatedProducts = products.filter(product => product.PRODUCTO !== productId);
      
      setProducts(updatedProducts);
      saveToCache(updatedProducts);
      
      logAction('DELETE_PRODUCT', productId, { 
        deletedAt: new Date().toISOString(),
        productData: productToDelete 
      });
      
      return true;
    } catch (err) {
      console.error('Error deleting product:', err);
      return false;
    }
  };

  const duplicateProduct = async (productId: string): Promise<boolean> => {
    try {
      const originalProduct = products.find(p => p.PRODUCTO === productId);
      if (!originalProduct) return false;

      const duplicatedProduct: Product = {
        ...originalProduct,
        "Unnamed: 0": `dup_${Date.now()}`,
        PRODUCTO: `${originalProduct.PRODUCTO} (Copia)`,
        "STOK ACTUAL": 0
      };

      const updatedProducts = [...products, duplicatedProduct];
      setProducts(updatedProducts);
      saveToCache(updatedProducts);
      
      logAction('DUPLICATE_PRODUCT', originalProduct.PRODUCTO);
      
      return true;
    } catch (err) {
      console.error('Error duplicating product:', err);
      return false;
    }
  };

  const importProducts = async (importedProducts: Product[]): Promise<boolean> => {
    try {
      // Crear backup antes de importar
      const backupData = {
        timestamp: new Date().toISOString(),
        products: products
      };
      localStorage.setItem('lilutecno_products_backup', JSON.stringify(backupData));

      setProducts(importedProducts);
      saveToCache(importedProducts);
      
      logAction('IMPORT_PRODUCTS', 'BULK_IMPORT', { 
        count: importedProducts.length,
        timestamp: new Date().toISOString()
      });
      
      return true;
    } catch (err) {
      console.error('Error importing products:', err);
      return false;
    }
  };

  const exportProducts = (): string => {
    const exportData = {
      timestamp: new Date().toISOString(),
      totalProducts: products.length,
      products: products
    };
    
    logAction('EXPORT_PRODUCTS', 'BULK_EXPORT', { 
      count: products.length,
      timestamp: new Date().toISOString()
    });
    
    return JSON.stringify(exportData, null, 2);
  };

  const getProductById = (id: string): Product | undefined => {
    return products.find(product => product.PRODUCTO === id);
  };

  // Obtener categorías únicas
  const categories = [...new Set(products.map(product => product.CATEGORIA))].filter(Boolean);

  // Obtener proveedores únicos
  const providers = [...new Set(products.map(product => product.PROVEEDOR))].filter(Boolean);

  return {
    products,
    loading,
    error,
    addProduct,
    updateProduct,
    deleteProduct,
    refreshProducts,
    categories,
    providers,
    getProductById,
    duplicateProduct,
    importProducts,
    exportProducts
  };
};

export default useProducts;
