import React, { createContext, useContext, useState, useEffect } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  user: { name: string; role: string } | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_PASSWORD = 'lilutecno2024';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ name: string; role: string } | null>(null);

  // Verificar si ya está autenticado al cargar
  useEffect(() => {
    const authData = localStorage.getItem('lilutecno_admin_auth');
    if (authData) {
      try {
        const { timestamp, isAuth } = JSON.parse(authData);
        // Verificar si la sesión no ha expirado (24 horas)
        const now = new Date().getTime();
        const sessionDuration = 24 * 60 * 60 * 1000; // 24 horas
        
        if (isAuth && (now - timestamp) < sessionDuration) {
          setIsAuthenticated(true);
          setUser({ name: 'Administrador', role: 'admin' });
        } else {
          localStorage.removeItem('lilutecno_admin_auth');
        }
      } catch (error) {
        localStorage.removeItem('lilutecno_admin_auth');
      }
    }
  }, []);

  const login = (password: string): boolean => {
    if (password === ADMIN_PASSWORD) {
      const authData = {
        timestamp: new Date().getTime(),
        isAuth: true
      };
      localStorage.setItem('lilutecno_admin_auth', JSON.stringify(authData));
      setIsAuthenticated(true);
      setUser({ name: 'Administrador', role: 'admin' });
      
      // Log de acceso
      const loginLog = {
        timestamp: new Date().toISOString(),
        action: 'LOGIN',
        user: 'admin'
      };
      const logs = JSON.parse(localStorage.getItem('lilutecno_admin_logs') || '[]');
      logs.push(loginLog);
      localStorage.setItem('lilutecno_admin_logs', JSON.stringify(logs.slice(-100))); // Mantener solo últimos 100 logs
      
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem('lilutecno_admin_auth');
    setIsAuthenticated(false);
    setUser(null);
    
    // Log de logout
    const logoutLog = {
      timestamp: new Date().toISOString(),
      action: 'LOGOUT',
      user: 'admin'
    };
    const logs = JSON.parse(localStorage.getItem('lilutecno_admin_logs') || '[]');
    logs.push(logoutLog);
    localStorage.setItem('lilutecno_admin_logs', JSON.stringify(logs.slice(-100)));
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
