import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types/Product';

interface WishlistContextType {
  wishlist: Product[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (product: Product) => void;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlist, setWishlist] = useState<Product[]>([]);

  // Cargar wishlist del localStorage al iniciar
  useEffect(() => {
    const savedWishlist = localStorage.getItem('lilutecno-wishlist');
    if (savedWishlist) {
      try {
        setWishlist(JSON.parse(savedWishlist));
      } catch (error) {
        console.error('Error loading wishlist:', error);
      }
    }
  }, []);

  // Guardar wishlist en localStorage cuando cambie
  useEffect(() => {
    localStorage.setItem('lilutecno-wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const addToWishlist = (product: Product) => {
    setWishlist(prev => {
      if (prev.some(item => item.PRODUCTO === product.PRODUCTO)) {
        return prev;
      }
      return [...prev, product];
    });
  };

  const removeFromWishlist = (productId: string) => {
    setWishlist(prev => prev.filter(item => item.PRODUCTO !== productId));
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some(item => item.PRODUCTO === productId);
  };

  const toggleWishlist = (product: Product) => {
    if (isInWishlist(product.PRODUCTO)) {
      removeFromWishlist(product.PRODUCTO);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <WishlistContext.Provider value={{
      wishlist,
      addToWishlist,
      removeFromWishlist,
      isInWishlist,
      toggleWishlist,
    }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
}
