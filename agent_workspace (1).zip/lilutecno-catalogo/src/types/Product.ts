export interface Product {
  "Unnamed: 0": string;
  "PRODUCTO": string;
  "IMAGEN 1": string;
  "IMAGEN 2": string;
  "IMAGEN 3": string;
  "IMAGEN 4": string;
  "IMAGEN 5": string;
  "DESCRICION": string;
  "CATEGORIA": string;
  "STOCK INICIAL": number;
  "ENTRADAS": number;
  "SALIDAS": number;
  "STOK ACTUAL": number;
  "PRECIO DE VENTA": number;
  "COSTO": number;
  "PROVEEDOR": string;
  "OBSERVACIONES": string;
  "imagen_principal"?: string;
}

export interface FilterState {
  search: string;
  category: string;
  priceRange: [number, number];
  inStock: boolean | null;
}
