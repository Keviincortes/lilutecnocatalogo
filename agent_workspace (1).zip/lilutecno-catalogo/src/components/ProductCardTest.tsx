import { motion } from 'framer-motion'
import { Product } from '../types/Product'

interface ProductCardTestProps {
  product: Product
  onClick: () => void
}

const ProductCardTest = ({ product, onClick }: ProductCardTestProps) => {
  return (
    <motion.div 
      className="card-elevated group cursor-pointer relative overflow-hidden will-change-transform
                 w-full max-w-sm mx-auto sm:max-w-none border border-gray-200 hover:border-orange-500 hover:shadow-lg
                 hover-lift animate-fade-in-up bg-white p-4 h-64"
      whileHover={{ y: -8, scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      onClick={(e) => {
        console.log('TEST: ProductCard clicked, opening modal for:', product.PRODUCTO)
        onClick()
      }}
    >
      <h3 className="text-lg font-bold">{product.PRODUCTO}</h3>
      <p className="text-sm text-gray-600">Precio: ${product["PRECIO DE VENTA"]}</p>
      <p className="text-xs text-gray-500">Click anywhere to open modal</p>
    </motion.div>
  )
}

export default ProductCardTest
