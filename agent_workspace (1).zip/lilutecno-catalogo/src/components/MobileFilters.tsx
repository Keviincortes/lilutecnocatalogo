import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Filter, X, Search, Package, DollarSign, Check } from 'lucide-react'
import { FilterState } from '../types/Product'

interface MobileFiltersProps {
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
  categories: string[]
  isOpen: boolean
  onToggle: () => void
}

const MobileFilters = ({ 
  filters, 
  onFiltersChange, 
  categories, 
  isOpen, 
  onToggle 
}: MobileFiltersProps) => {
  const [tempFilters, setTempFilters] = useState<FilterState>(filters)

  const handleApplyFilters = () => {
    onFiltersChange(tempFilters)
    onToggle()
  }

  const handleResetFilters = () => {
    const resetFilters: FilterState = {
      search: '',
      category: '',
      priceRange: [0, 2000000],
      inStock: null
    }
    setTempFilters(resetFilters)
    onFiltersChange(resetFilters)
    onToggle()
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(price)
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40"
            onClick={onToggle}
          />

          {/* Filter Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-sm bg-white z-50 shadow-2xl overflow-y-auto"
          >
            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-gray-600" />
                <h2 className="text-lg font-semibold text-gray-900">Filtros</h2>
              </div>
              <button
                onClick={onToggle}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Filter Content */}
            <div className="p-4 space-y-6">
              {/* Search */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Search className="h-4 w-4 inline mr-1" />
                  Buscar productos
                </label>
                <input
                  type="text"
                  value={tempFilters.search}
                  onChange={(e) => setTempFilters(prev => ({ ...prev, search: e.target.value }))}
                  placeholder="Escribe para buscar..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-base"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  <Package className="h-4 w-4 inline mr-1" />
                  Categoría
                </label>
                <div className="space-y-2">
                  <button
                    onClick={() => setTempFilters(prev => ({ ...prev, category: '' }))}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                      tempFilters.category === '' 
                        ? 'bg-orange-100 text-orange-700 border border-orange-300' 
                        : 'bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>Todas las categorías</span>
                      {tempFilters.category === '' && <Check className="h-4 w-4" />}
                    </div>
                  </button>
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setTempFilters(prev => ({ ...prev, category }))}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                        tempFilters.category === category 
                          ? 'bg-orange-100 text-orange-700 border border-orange-300' 
                          : 'bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm">{category}</span>
                        {tempFilters.category === category && <Check className="h-4 w-4" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  <DollarSign className="h-4 w-4 inline mr-1" />
                  Rango de precios
                </label>
                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <div className="flex-1">
                      <label className="block text-xs text-gray-500 mb-1">Mínimo</label>
                      <input
                        type="number"
                        value={tempFilters.priceRange[0]}
                        onChange={(e) => setTempFilters(prev => ({ 
                          ...prev, 
                          priceRange: [Number(e.target.value), prev.priceRange[1]] 
                        }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        placeholder="0"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-xs text-gray-500 mb-1">Máximo</label>
                      <input
                        type="number"
                        value={tempFilters.priceRange[1]}
                        onChange={(e) => setTempFilters(prev => ({ 
                          ...prev, 
                          priceRange: [prev.priceRange[0], Number(e.target.value)] 
                        }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        placeholder="2000000"
                      />
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 text-center">
                    {formatPrice(tempFilters.priceRange[0])} - {formatPrice(tempFilters.priceRange[1])}
                  </div>
                </div>
              </div>

              {/* Stock */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  <Package className="h-4 w-4 inline mr-1" />
                  Disponibilidad
                </label>
                <div className="space-y-2">
                  <button
                    onClick={() => setTempFilters(prev => ({ ...prev, inStock: null }))}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                      tempFilters.inStock === null 
                        ? 'bg-orange-100 text-orange-700 border border-orange-300' 
                        : 'bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>Todos los productos</span>
                      {tempFilters.inStock === null && <Check className="h-4 w-4" />}
                    </div>
                  </button>
                  <button
                    onClick={() => setTempFilters(prev => ({ ...prev, inStock: true }))}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                      tempFilters.inStock === true 
                        ? 'bg-green-100 text-green-700 border border-green-300' 
                        : 'bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>Solo disponibles</span>
                      {tempFilters.inStock === true && <Check className="h-4 w-4" />}
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 space-y-3">
              <button
                onClick={handleApplyFilters}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 px-4 rounded-lg font-semibold hover:from-orange-600 hover:to-red-600 transition-all shadow-lg active:shadow-md"
              >
                Aplicar filtros
              </button>
              <button
                onClick={handleResetFilters}
                className="w-full bg-gray-100 text-gray-700 py-3 px-4 rounded-lg font-semibold hover:bg-gray-200 transition-all"
              >
                Limpiar filtros
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default MobileFilters
