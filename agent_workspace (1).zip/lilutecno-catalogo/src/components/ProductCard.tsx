import { Package, Eye, AlertCircle, Heart, ShoppingCart, Zap, Clock, Star, MessageCircle } from 'lucide-react'
import { motion } from 'framer-motion'
import { Product } from '../types/Product'
import { calculateOffer, getOfferColor, getUrgencyColor, formatPrice } from '../utils/offers'
import { useCart } from '../contexts/CartContext'
import { useWishlist } from '../contexts/WishlistContext'
import { generateProductWhatsAppMessage } from '../utils/whatsapp'
import ProductImage from './ProductImage'
import WhatsAppButton from './ui/WhatsAppButton'

interface ProductCardProps {
  product: Product
  onClick: () => void
}

const ProductCard = ({ product, onClick }: ProductCardProps) => {
  const { addToCart, isInCart } = useCart()
  const { toggleWishlist, isInWishlist } = useWishlist()
  const offer = calculateOffer(product)
  
  const isInStock = product["STOK ACTUAL"] > 0
  const stockText = isInStock ? `${product["STOK ACTUAL"]} disponibles` : 'Sin stock'

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (isInStock) {
      addToCart(product)
    }
  }

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation()
    toggleWishlist(product)
  }

  const whatsappMessage = generateProductWhatsAppMessage(product)

  return (
    <motion.div 
      className="card-elevated group cursor-pointer relative overflow-hidden will-change-transform
                 w-full max-w-sm mx-auto sm:max-w-none border border-gray-200 hover:border-orange-500 hover:shadow-lg
                 hover-lift animate-fade-in-up"
      whileHover={{ y: -8, scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      onClick={onClick}
    >
      {/* Badges flotantes */}
      <div className="absolute top-2 left-2 z-10 flex flex-col gap-1 max-w-[60%]">
        {offer.hasOffer && (
          <motion.div
            className={`px-2 py-1 rounded-lg text-xs sm:text-sm font-bold shadow-lg ${getOfferColor(offer.offerType)}`}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {offer.badge}
          </motion.div>
        )}
        
        {offer.urgencyLevel === 'HIGH' && (
          <motion.div
            className={`px-2 py-1 rounded-lg text-xs font-bold border ${getUrgencyColor(offer.urgencyLevel)}`}
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Clock className="h-3 w-3 inline mr-1" />
            <span className="hidden sm:inline">¡Última oportunidad!</span>
            <span className="sm:hidden">¡Últimas!</span>
          </motion.div>
        )}
      </div>

      {/* Corazón de wishlist */}
      <motion.button
        className={`absolute top-2 right-2 z-10 p-2 sm:p-2.5 rounded-full ${
          isInWishlist(product.PRODUCTO) 
            ? 'bg-red-500 text-white' 
            : 'bg-white/90 text-gray-600 hover:text-red-500'
        } shadow-lg transition-colors touch-manipulation`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={handleToggleWishlist}
      >
        <Heart className={`h-4 w-4 sm:h-5 sm:w-5 ${isInWishlist(product.PRODUCTO) ? 'fill-current' : ''}`} />
      </motion.button>

      {/* Imagen del producto */}
      <div className="relative h-48 sm:h-52 md:h-56 lg:h-48 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
        <ProductImage
          producto={product.PRODUCTO}
          categoria={product.CATEGORIA}
          imagenPrincipal={product.imagen_principal}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        
        {/* Overlay de descuento */}
        {offer.hasOffer && (
          <div className="absolute bottom-2 left-2 bg-red-500 text-white px-2 py-1 sm:px-3 rounded-full text-xs sm:text-sm font-bold shadow-lg">
            -{offer.discountPercentage}%
          </div>
        )}

        {/* Quick view overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
          <motion.div
            className="bg-white rounded-full p-2 sm:p-3 opacity-0 group-hover:opacity-100 transition-all duration-300"
            whileHover={{ scale: 1.1 }}
          >
            <Eye className="h-4 w-4 sm:h-5 sm:w-5 text-gray-700" />
          </motion.div>
        </div>
      </div>

      {/* Contenido de la tarjeta */}
      <div className="p-3 sm:p-4">
        {/* Título del producto */}
        <h3 className="font-bold text-gray-900 text-sm sm:text-base leading-tight group-hover:text-orange-600 transition-colors line-clamp-2 mb-2 min-h-[2.5rem] sm:min-h-[3rem]">
          {product.PRODUCTO}
        </h3>

        {/* Rating simulado */}
        <div className="flex items-center mb-2 sm:mb-3">
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-3 w-3 sm:h-4 sm:w-4 fill-current" />
            ))}
          </div>
          <span className="text-xs sm:text-sm text-gray-500 ml-1">(4.8) · 127 vendidos</span>
        </div>

        {/* Precios */}
        <div className="mb-3 sm:mb-4">
          {offer.hasOffer ? (
            <div className="space-y-1">
              <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                <span className="text-xl sm:text-2xl lg:text-xl font-black text-red-600">
                  {formatPrice(offer.currentPrice)}
                </span>
                <span className="text-xs sm:text-sm text-gray-500 line-through">
                  {formatPrice(offer.originalPrice)}
                </span>
              </div>
              <div className="text-xs sm:text-sm text-green-600 font-semibold">
                ¡Ahorras {formatPrice(offer.originalPrice - offer.currentPrice)}!
              </div>
            </div>
          ) : (
            <div className="text-xl sm:text-2xl lg:text-xl font-black text-gray-900">
              {formatPrice(product["PRECIO DE VENTA"])}
            </div>
          )}
        </div>

        {/* Stock */}
        <div className="mb-2 sm:mb-3">
          <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs sm:text-sm font-bold ${
            isInStock 
              ? offer.urgencyLevel === 'HIGH'
                ? 'bg-red-100 text-red-800 animate-pulse' 
                : 'bg-green-100 text-green-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {isInStock ? (
              <>
                <Package className="h-3 w-3 mr-1" />
                {product["STOK ACTUAL"] <= 5 ? (
                  `¡Solo ${product["STOK ACTUAL"]} disponibles!`
                ) : (
                  stockText
                )}
              </>
            ) : (
              <>
                <AlertCircle className="h-3 w-3 mr-1" />
                {stockText}
              </>
            )}
          </div>
        </div>

        {/* Envío gratis si el margen es alto */}
        {offer.margin > 40 && (
          <div className="mb-2 sm:mb-3">
            <div className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs sm:text-sm font-semibold">
              <Zap className="h-3 w-3 mr-1" />
              ENVÍO GRATIS
            </div>
          </div>
        )}

        {/* Botones de acción */}
        <div className="space-y-2 sm:space-y-3">
          <motion.button
            className={`w-full mobile-button focus-ring ${
              isInStock && !isInCart(product.PRODUCTO)
                ? 'btn-conversion animate-pulse-glow'
                : isInCart(product.PRODUCTO)
                ? 'btn-trust'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
            whileHover={isInStock ? { scale: 1.05, y: -2 } : {}}
            whileTap={isInStock ? { scale: 0.95 } : {}}
            onClick={handleAddToCart}
            disabled={!isInStock}
          >
            <ShoppingCart className="h-4 w-4 sm:h-5 sm:w-5 inline mr-2" />
            {isInCart(product.PRODUCTO) ? 'En carrito' : 'Agregar al carrito'}
          </motion.button>

          <div onClick={(e) => e.stopPropagation()}>
            <WhatsAppButton
              message={whatsappMessage}
              size="md"
              className="w-full mobile-button"
            >
              <span className="hidden sm:inline">COMPRAR POR WHATSAPP</span>
              <span className="sm:hidden">COMPRAR</span>
            </WhatsAppButton>
          </div>
        </div>
      </div>

      {/* Efecto de brillo en hover */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none" />
    </motion.div>
  )
}

export default ProductCard
