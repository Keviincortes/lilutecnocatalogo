import { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Package, ImageIcon } from 'lucide-react'

interface ProductImageProps {
  producto: string
  categoria: string
  imagenPrincipal?: string
  className?: string
  loading?: 'lazy' | 'eager'
  onClick?: () => void
}

const ProductImage = ({ 
  producto, 
  categoria, 
  imagenPrincipal, 
  className = "w-full h-full object-cover", 
  loading = 'lazy',
  onClick 
}: ProductImageProps) => {
  const [imageStatus, setImageStatus] = useState<'loading' | 'loaded' | 'error'>('loading')
  const [isInView, setIsInView] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Lazy loading intersection observer
  useEffect(() => {
    if (loading === 'eager') {
      setIsInView(true)
      return
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true)
          observer.disconnect()
        }
      },
      {
        threshold: 0.1,
        rootMargin: '50px'
      }
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => observer.disconnect()
  }, [loading])

  // Función para obtener la imagen principal del producto
  const getProductImage = () => {
    if (imagenPrincipal) {
      // Si tiene imagen principal asignada, usarla
      return `/${imagenPrincipal}`
    }
    return null
  }

  // Función para obtener imagen de respaldo por categoría
  const getCategoryFallbackImage = (categoria: string): string => {
    const imageMap: { [key: string]: string } = {
      'TELEVISOR': '/images/televisor-smart-65.jpeg',
      'AUDIO Y SONIDO': '/images/audio-headphones.jpg',
      'COCINA': '/images/cocina-appliances.jpg',
      'HOGAR': '/images/hogar-smart.png',
      'BEBES Y JUGUETES': '/images/bebes-juguetes.jpg',
      'CONTROLES Y CONSOLAS GAMER': '/images/gaming-console.jpg',
      'ACCESORIOS PARA CARRO': '/images/auto-accessories.jpg',
      'SALUD Y BELLEZA': '/images/belleza-cosmeticos.jpg',
      'CUIDADO PERSONAL': '/images/belleza-cosmeticos.jpg',
    }
    
    return imageMap[categoria] || '/images/televisor-smart-65.jpeg'
  }

  const handleImageLoad = () => {
    setImageStatus('loaded')
  }

  const handleImageError = () => {
    setImageStatus('error')
  }

  const primaryImageSrc = getProductImage()
  const fallbackImageSrc = getCategoryFallbackImage(categoria)

  if (!isInView) {
    return (
      <div 
        ref={containerRef} 
        className={`bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center ${className}`}
        onClick={onClick}
      >
        <div className="text-gray-400 flex flex-col items-center space-y-2">
          <Package className="h-8 w-8" />
          <span className="text-xs text-center px-2">Cargando imagen...</span>
        </div>
      </div>
    )
  }

  return (
    <div 
      ref={containerRef} 
      className={`relative overflow-hidden ${className}`}
      onClick={onClick}
    >
      {/* Loading state */}
      {imageStatus === 'loading' && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="text-gray-400"
          >
            <Package className="h-8 w-8" />
          </motion.div>
        </div>
      )}

      {/* Primary image */}
      {primaryImageSrc && imageStatus !== 'error' && (
        <img
          ref={imgRef}
          src={primaryImageSrc}
          alt={producto}
          className={`${className} transition-all duration-500 ${
            imageStatus === 'loaded' ? 'opacity-100' : 'opacity-0'
          }`}
          onLoad={handleImageLoad}
          onError={handleImageError}
          loading={loading}
        />
      )}

      {/* Fallback image */}
      {(imageStatus === 'error' || !primaryImageSrc) && (
        <img
          src={fallbackImageSrc}
          alt={`${categoria} - ${producto}`}
          className={className}
          onError={(e) => {
            // Si también falla la imagen de respaldo, mostrar placeholder
            e.currentTarget.style.display = 'none'
          }}
        />
      )}

      {/* Error state placeholder */}
      {imageStatus === 'error' && !primaryImageSrc && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
          <div className="text-gray-400 flex flex-col items-center space-y-2">
            <ImageIcon className="h-8 w-8" />
            <span className="text-xs text-center px-2">
              {categoria}
            </span>
          </div>
        </div>
      )}

      {/* Optimized loading animation overlay */}
      {imageStatus === 'loading' && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12"
          animate={{
            x: ['-100%', '100%']
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}
    </div>
  )
}

export default ProductImage
