import { Search, ShoppingCart, Heart, Gift, Zap, MessageCircle, Filter } from 'lucide-react'
import { motion } from 'framer-motion'
import { useCart } from '../contexts/CartContext'
import { useWishlist } from '../contexts/WishlistContext'
import { formatPrice } from '../utils/offers'

interface HeaderProps {
  productCount: number
  totalCount: number
  onOpenCart: () => void
  onOpenFilters?: () => void
}

const Header = ({ productCount, totalCount, onOpenCart, onOpenFilters }: HeaderProps) => {
  const { state: cartState } = useCart()
  const { wishlist } = useWishlist()

  return (
    <header className="bg-gradient-to-r from-orange-500 via-red-500 to-purple-600 shadow-2xl">
      {/* Banner promocional persuasivo */}
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-center py-2 px-2">
        <motion.div
          className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm lg:text-base font-black"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <Zap className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5" />
          <span className="truncate">🔥 ¡OFERTAS MUNDIALES! Hasta 70% OFF 🔥</span>
          <Zap className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5" />
        </motion.div>
      </div>

      <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-4">
        <div className="space-y-3 sm:space-y-0">
          {/* Primera fila: Logo y acciones principales */}
          <div className="flex items-center justify-between">
            {/* Logo y título */}
            <motion.div 
              className="flex items-center space-x-2 sm:space-x-3"
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <motion.div 
                className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center shadow-lg"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                <span className="text-orange-500 font-black text-lg sm:text-xl">L</span>
              </motion.div>
              <div>
                <h1 className="heading-responsive text-white drop-shadow-lg">LiluTecno</h1>
                <p className="body-responsive text-orange-100 hidden sm:block">🌍 ¡Tecnología Mundial a Tu Alcance!</p>
              </div>
            </motion.div>

            {/* Iconos de acción */}
            <motion.div 
              className="flex items-center space-x-2 sm:space-x-4"
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {/* Filtros móviles */}
              <motion.div 
                className="relative cursor-pointer sm:hidden focus-ring"
                whileHover={{ scale: 1.15, y: -2 }}
                whileTap={{ scale: 0.9 }}
                onClick={onOpenFilters}
              >
                <div className="p-2 bg-white/30 rounded-lg backdrop-blur-md shadow-lg hover:shadow-xl transition-all">
                  <Filter className="h-5 w-5 text-white" />
                </div>
              </motion.div>

              {/* Wishlist */}
              <motion.div 
                className="relative cursor-pointer focus-ring"
                whileHover={{ scale: 1.15, y: -2 }}
                whileTap={{ scale: 0.9 }}
              >
                <div className="p-2 sm:p-3 bg-white/30 rounded-lg sm:rounded-xl backdrop-blur-md shadow-lg hover:shadow-xl transition-all">
                  <Heart className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  {wishlist.length > 0 && (
                    <motion.span
                      className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 bg-green-500 text-white text-xs font-bold rounded-full h-4 w-4 sm:h-6 sm:w-6 flex items-center justify-center animate-bounce"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity }}
                    >
                      {wishlist.length}
                    </motion.span>
                  )}
                </div>
              </motion.div>

              {/* Carrito */}
              <motion.div 
                className="relative cursor-pointer focus-ring"
                whileHover={{ scale: 1.15, y: -2 }}
                whileTap={{ scale: 0.9 }}
                onClick={onOpenCart}
              >
                <div className="p-2 sm:p-3 bg-white/30 rounded-lg sm:rounded-xl backdrop-blur-md shadow-lg hover:shadow-xl transition-colors">
                  <ShoppingCart className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  {cartState.itemCount > 0 && (
                    <motion.span
                      className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 bg-green-500 text-white text-xs font-bold rounded-full h-4 w-4 sm:h-6 sm:w-6 flex items-center justify-center animate-pulse"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 0.7, repeat: Infinity }}
                    >
                      {cartState.itemCount}
                    </motion.span>
                  )}
                </div>
                {cartState.total > 0 && (
                  <div className="absolute top-full mt-1 left-1/2 transform -translate-x-1/2 bg-white text-gray-800 px-2 py-1 rounded-lg text-xs font-bold whitespace-nowrap shadow-lg hidden sm:block animate-bounce-in">
                    💰 {formatPrice(cartState.total)}
                  </div>
                )}
              </motion.div>

              {/* WhatsApp directo */}
              <motion.div 
                className="relative cursor-pointer focus-ring"
                whileHover={{ scale: 1.15, y: -2 }}
                whileTap={{ scale: 0.9 }}
              >
                <div className="p-2 sm:p-3 bg-green-500 rounded-lg sm:rounded-xl shadow-lg hover:bg-green-600 transition-all hover:shadow-xl">
                  <MessageCircle className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  <motion.span
                    className="absolute -top-1 -right-1 bg-yellow-500 text-white text-xs font-bold rounded-full h-3 w-3 sm:h-4 sm:w-4 flex items-center justify-center animate-pulse"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1.2, repeat: Infinity }}
                  >
                    🔥
                  </motion.span>
                </div>
              </motion.div>

              {/* Ofertas especiales */}
              <motion.div 
                className="relative cursor-pointer hidden sm:block"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="p-3 bg-yellow-400 rounded-xl shadow-lg">
                  <Gift className="h-6 w-6 text-red-600" />
                  <motion.span
                    className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    !
                  </motion.span>
                </div>
              </motion.div>
            </motion.div>
          </div>

          {/* Segunda fila: Barra de búsqueda en móviles */}
          <div className="w-full">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 sm:h-5 sm:w-5" />
              <input
                type="text"
                placeholder="Busca tu producto favorito..."
                className="w-full pl-9 sm:pl-10 pr-4 py-2.5 sm:py-3 rounded-lg sm:rounded-xl border-none shadow-lg focus:ring-4 focus:ring-orange-300 outline-none text-gray-700 placeholder-gray-500 text-sm sm:text-base"
              />
            </div>
          </div>
        </div>

        {/* Estadísticas mejoradas */}
        <motion.div 
          className="grid grid-cols-2 sm:flex sm:items-center sm:justify-center gap-4 sm:space-x-8 mt-4 pt-4 border-t border-white/20"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="text-center">
            <div className="text-xl sm:text-3xl font-black text-white drop-shadow-lg">{productCount}</div>
            <div className="text-xs sm:text-sm text-orange-100">En oferta</div>
          </div>
          <div className="text-center">
            <div className="text-xl sm:text-3xl font-black text-white drop-shadow-lg">{totalCount}</div>
            <div className="text-xs sm:text-sm text-orange-100">Disponibles</div>
          </div>
          <div className="text-center">
            <div className="text-xl sm:text-3xl font-black text-white drop-shadow-lg">24h</div>
            <div className="text-xs sm:text-sm text-orange-100">Envío</div>
          </div>
          <div className="text-center">
            <div className="text-xl sm:text-3xl font-black text-white drop-shadow-lg">100%</div>
            <div className="text-xs sm:text-sm text-orange-100">Garantía</div>
          </div>
        </motion.div>

        {/* Nuevo: Call to action para WhatsApp */}
        {cartState.itemCount > 0 && (
          <motion.div 
            className="mt-4 bg-green-500 rounded-xl p-3 text-center cursor-pointer hover:bg-green-600 transition-colors"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
            onClick={onOpenCart}
          >
            <div className="flex items-center justify-center gap-2 text-white font-bold">
              <MessageCircle className="h-5 w-5" />
              ¡{cartState.itemCount} producto{cartState.itemCount > 1 ? 's' : ''} en tu carrito! 
              <span className="bg-white text-green-600 px-2 py-1 rounded-lg text-sm">
                Solicitar Cotización →
              </span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Ondas decorativas */}
      <div className="relative">
        <svg className="w-full h-4" viewBox="0 0 1200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 20 Q300 0 600 20 T1200 20 V40 H0 V20Z" fill="white"/>
        </svg>
      </div>
    </header>
  )
}

export default Header
