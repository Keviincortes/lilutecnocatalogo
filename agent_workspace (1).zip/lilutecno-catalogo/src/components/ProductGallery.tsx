import React, { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, X, ZoomIn, Package } from 'lucide-react'

interface ProductGalleryProps {
  images: string[]
  productName: string
  className?: string
  showThumbnails?: boolean
  autoPlay?: boolean
}

const ProductGallery = ({ 
  images, 
  productName, 
  className = '',
  showThumbnails = true,
  autoPlay = false
}: ProductGalleryProps) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showFullscreen, setShowFullscreen] = useState(false)
  const [isZoomed, setIsZoomed] = useState(false)
  const [zoomPosition, setZoomPosition] = useState({ x: 0, y: 0 })
  const [imageLoadStates, setImageLoadStates] = useState<{ [key: number]: 'loading' | 'loaded' | 'error' }>({})
  
  const imageRef = useRef<HTMLImageElement>(null)

  // Filtrar imágenes válidas
  const validImages = (images || []).filter(img => img && img.trim() !== '')
  
  if (validImages.length === 0) {
    return (
      <div className={`relative overflow-hidden bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center ${className}`}>
        <div className="text-center">
          <Package className="h-8 w-8 text-gray-500 mx-auto mb-2" />
          <p className="text-xs text-gray-500">Sin imágenes</p>
        </div>
      </div>
    )
  }

  const currentImage = validImages[currentImageIndex]
  const currentLoadState = imageLoadStates[currentImageIndex] || 'loading'

  const handleImageLoad = (index: number) => {
    setImageLoadStates(prev => ({ ...prev, [index]: 'loaded' }))
  }

  const handleImageError = (index: number) => {
    setImageLoadStates(prev => ({ ...prev, [index]: 'error' }))
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % validImages.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + validImages.length) % validImages.length)
  }

  const goToImage = (index: number) => {
    setCurrentImageIndex(index)
  }

  const openFullscreen = () => {
    setShowFullscreen(true)
  }

  const closeFullscreen = () => {
    setShowFullscreen(false)
    setIsZoomed(false)
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageRef.current) return
    
    const rect = imageRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setZoomPosition({ x, y })
  }

  // Auto-play functionality
  React.useEffect(() => {
    if (!autoPlay || validImages.length <= 1) return

    const interval = setInterval(() => {
      nextImage()
    }, 3000)

    return () => clearInterval(interval)
  }, [autoPlay, validImages.length])

  return (
    <>
      {/* Galería principal */}
      <div className={`relative overflow-hidden group cursor-pointer ${className}`}>
        {/* Imagen principal */}
        <div 
          className="relative w-full h-full"
          onClick={openFullscreen}
          onMouseMove={handleMouseMove}
        >
          {currentLoadState === 'loading' && (
            <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
              <div className="text-center">
                <div className="w-6 h-6 border-2 border-gray-400/30 border-t-gray-400 rounded-full animate-spin mx-auto mb-2"></div>
                <p className="text-xs text-gray-500">Cargando...</p>
              </div>
            </div>
          )}
          
          {currentLoadState === 'error' ? (
            <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
              <div className="text-center">
                <Package className="h-8 w-8 text-gray-500 mx-auto mb-2" />
                <p className="text-xs text-gray-500">Error al cargar</p>
              </div>
            </div>
          ) : (
            <motion.img
              ref={imageRef}
              key={currentImageIndex}
              src={currentImage.startsWith('/') ? currentImage : `/${currentImage}`}
              alt={`${productName} - Imagen ${currentImageIndex + 1}`}
              className="w-full h-full object-cover transition-all duration-300"
              initial={{ opacity: 0 }}
              animate={{ opacity: currentLoadState === 'loaded' ? 1 : 0 }}
              transition={{ duration: 0.3 }}
              onLoad={() => handleImageLoad(currentImageIndex)}
              onError={() => handleImageError(currentImageIndex)}
              whileHover={{ scale: 1.02 }}
            />
          )}
        </div>

        {/* Controles de navegación - solo si hay múltiples imágenes */}
        {validImages.length > 1 && (
          <>
            <button
              onClick={(e) => { e.stopPropagation(); prevImage(); }}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-black/70 hover:scale-110"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); nextImage(); }}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-black/70 hover:scale-110"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            
            {/* Indicadores de imagen */}
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
              {validImages.map((_, index) => (
                <button
                  key={index}
                  onClick={(e) => { e.stopPropagation(); goToImage(index); }}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentImageIndex 
                      ? 'bg-white shadow-lg scale-125' 
                      : 'bg-white/50 hover:bg-white/75'
                  }`}
                />
              ))}
            </div>
            
            {/* Contador de imágenes */}
            <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded-lg text-xs opacity-0 group-hover:opacity-100 transition-opacity">
              {currentImageIndex + 1}/{validImages.length}
            </div>
          </>
        )}

        {/* Icono de zoom */}
        <div className="absolute top-2 right-2 bg-white/90 text-gray-700 p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
          <ZoomIn className="h-4 w-4" />
        </div>
      </div>

      {/* Thumbnails */}
      {showThumbnails && validImages.length > 1 && (
        <div className="flex space-x-2 mt-2 overflow-x-auto pb-2">
          {validImages.map((image, index) => (
            <button
              key={index}
              onClick={() => goToImage(index)}
              className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                index === currentImageIndex 
                  ? 'border-orange-500 shadow-lg scale-105' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <img
                src={image.startsWith('/') ? image : `/${image}`}
                alt={`${productName} thumbnail ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      )}

      {/* Modal de pantalla completa */}
      <AnimatePresence>
        {showFullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
            onClick={closeFullscreen}
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              className="relative max-w-6xl max-h-full flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Imagen principal en fullscreen */}
              <div className="relative flex-1 flex items-center justify-center">
                <motion.img
                  src={currentImage.startsWith('/') ? currentImage : `/${currentImage}`}
                  alt={`${productName} - Imagen ${currentImageIndex + 1}`}
                  className="max-w-full max-h-full object-contain cursor-zoom-in"
                  style={{
                    transform: isZoomed ? `scale(2) translate(-${zoomPosition.x - 50}%, -${zoomPosition.y - 50}%)` : 'scale(1)'
                  }}
                  onClick={(e) => {
                    e.stopPropagation()
                    setIsZoomed(!isZoomed)
                  }}
                  onMouseMove={handleMouseMove}
                />
              </div>
              
              {/* Controles */}
              <div className="absolute top-4 right-4 flex space-x-2">
                <button
                  onClick={() => setIsZoomed(!isZoomed)}
                  className="bg-black/50 text-white p-3 rounded-full hover:bg-black/70 transition-colors"
                >
                  <ZoomIn className="h-5 w-5" />
                </button>
                <button
                  onClick={closeFullscreen}
                  className="bg-black/50 text-white p-3 rounded-full hover:bg-black/70 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              {/* Navegación en pantalla completa */}
              {validImages.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-4 rounded-full hover:bg-black/70 transition-colors"
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-4 rounded-full hover:bg-black/70 transition-colors"
                  >
                    <ChevronRight className="h-6 w-6" />
                  </button>
                  
                  {/* Thumbnails en fullscreen */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 max-w-full overflow-x-auto p-2">
                    {validImages.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => goToImage(index)}
                        className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                          index === currentImageIndex ? 'border-white shadow-lg' : 'border-white/30 hover:border-white/60'
                        }`}
                      >
                        <img
                          src={image.startsWith('/') ? image : `/${image}`}
                          alt={`${productName} thumbnail ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </>
              )}
              
              {/* Información de la imagen */}
              <div className="absolute top-4 left-4 bg-black/50 text-white px-4 py-2 rounded-lg">
                <p className="text-sm font-medium">{productName}</p>
                <p className="text-xs text-gray-300">
                  Imagen {currentImageIndex + 1} de {validImages.length}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

export default ProductGallery
