import { Product } from '../types/Product'
import ProductCard from './ProductCard'

interface ProductGridProps {
  products: Product[]
  onProductClick: (product: Product) => void
}

const ProductGrid = ({ products, onProductClick }: ProductGridProps) => {
  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-24 h-24 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-xl font-semibold text-gray-700 mb-2">No se encontraron productos</h3>
        <p className="text-gray-500">Intenta ajustar los filtros para ver más resultados.</p>
      </div>
    )
  }

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 sm:mb-6 px-2 sm:px-0">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-2 sm:mb-0">
          Productos ({products.length.toLocaleString()})
        </h2>
        <div className="text-sm text-gray-500">
          Mostrando todos los resultados
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-4 lg:gap-6 px-2 sm:px-0">
        {products.map((product, index) => (
          <ProductCard 
            key={`${product.PRODUCTO}-${index}`}
            product={product}
            onClick={() => onProductClick(product)}
          />
        ))}
      </div>
    </div>
  )
}

export default ProductGrid
