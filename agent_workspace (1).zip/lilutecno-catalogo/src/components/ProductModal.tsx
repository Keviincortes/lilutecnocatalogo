import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Star, ShoppingCart, Heart, MessageCircle } from 'lucide-react'
import { Product } from '../types/Product'
import { formatPrice } from '../utils/offers'
import { useCountdown } from '../hooks/useCountdown'
import { useCart } from '../contexts/CartContext'
import { useWishlist } from '../contexts/WishlistContext'
import { generateProductWhatsAppMessage } from '../utils/whatsapp'
import ProductGallery from './ProductGallery'
import Modal from './ui/Modal'
import WhatsAppButton from './ui/WhatsAppButton'

interface ProductModalProps {
  product: Product
  isOpen: boolean
  onClose: () => void
}

const ProductModal: React.FC<ProductModalProps> = ({ product, isOpen, onClose }) => {
  const { addToCart } = useCart()
  const { isInWishlist, toggleWishlist } = useWishlist()
  const [quantity, setQuantity] = useState(1)
  const [showAddedToCart, setShowAddedToCart] = useState(false)

  // Sistema de ofertas con countdown
  const [offer] = useState(() => {
    const offers = [
      { hasOffer: true, percentage: 20, endTime: Date.now() + 4 * 60 * 60 * 1000 },
      { hasOffer: true, percentage: 15, endTime: Date.now() + 2 * 60 * 60 * 1000 },
      { hasOffer: false, percentage: 0, endTime: 0 }
    ]
    return offers[Math.floor(Math.random() * offers.length)]
  })
  
  const timeLeft = useCountdown(new Date(offer.endTime))
  const originalPrice = product["PRECIO DE VENTA"]
  const discountedPrice = offer.hasOffer ? originalPrice * (1 - offer.percentage / 100) : originalPrice

  useEffect(() => {
    if (showAddedToCart) {
      const timer = setTimeout(() => setShowAddedToCart(false), 3000)
      return () => clearTimeout(timer)
    }
  }, [showAddedToCart])

  const handleAddToCart = () => {
    addToCart(product, quantity)
    setShowAddedToCart(true)
    setTimeout(() => {
      onClose()
    }, 1500)
  }

  const whatsappMessage = generateProductWhatsAppMessage(product)

  const formatDescription = (description: string) => {
    if (!description || description.trim() === '') return 'Descripción no disponible'
    
    return description
      .split(/[,\n]/)
      .map(item => item.trim())
      .filter(item => item.length > 0)
      .slice(0, 6)
      .join(', ')
      .trim()
  }

  if (!isOpen) return null

  return (
    <Modal 
      isOpen={isOpen}
      onClose={onClose}
      size="xl"
    >
      <div className="min-h-96">
        {/* Header con ofertas */}
        <div className="relative bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 text-white p-4">
          {offer.hasOffer && (
            <motion.div 
              className="text-center"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="text-xl font-black">¡OFERTA ESPECIAL!</div>
              <div className="text-2xl font-black">{offer.percentage}% DE DESCUENTO</div>
              <div className="text-sm">
                ⏰ Tiempo restante: {timeLeft.hours}h {timeLeft.minutes}m {timeLeft.seconds}s
              </div>
            </motion.div>
          )}
        </div>

        {/* Contenido principal */}
        <div className="flex flex-col lg:flex-row gap-6 p-6">
          {/* Galería de imágenes */}
          <div className="lg:w-1/2">
            <ProductGallery 
              images={[product["IMAGEN 1"], product["IMAGEN 2"], product["IMAGEN 3"], product["IMAGEN 4"], product["IMAGEN 5"]].filter(Boolean)} 
              productName={product.PRODUCTO}
            />
          </div>

          {/* Información del producto */}
          <div className="lg:w-1/2 space-y-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{product.PRODUCTO}</h2>
              
              {/* Rating y stock */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-500 ml-1">(4.8)</span>
                </div>
                <div className="text-sm">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                    product["STOK ACTUAL"] > 10 
                      ? 'bg-green-100 text-green-800' 
                      : product["STOK ACTUAL"] > 0 
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {product["STOK ACTUAL"] > 10 ? 'En Stock' : product["STOK ACTUAL"] > 0 ? `Solo ${product["STOK ACTUAL"]} disponibles` : 'Agotado'}
                  </span>
                </div>
              </div>

              {/* Precios */}
              <div className="mb-4">
                {offer.hasOffer ? (
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl font-bold text-green-600">
                        {formatPrice(discountedPrice)}
                      </span>
                      <span className="text-lg text-gray-500 line-through">
                        {formatPrice(originalPrice)}
                      </span>
                    </div>
                    <div className="text-sm text-green-600 font-semibold">
                      ¡Ahorras {formatPrice(originalPrice - discountedPrice)}!
                    </div>
                  </div>
                ) : (
                  <div className="text-3xl font-bold text-gray-900">
                    {formatPrice(product["PRECIO DE VENTA"])}
                  </div>
                )}
              </div>

              {/* Descripción */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-2">Descripción:</h3>
                <p className="text-gray-600 leading-relaxed">
                  {formatDescription(product.DESCRICION)}
                </p>
              </div>

              {/* Información adicional */}
              <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                <div>
                  <span className="font-semibold text-gray-700">Categoría:</span>
                  <p className="text-gray-600">{product.CATEGORIA}</p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Proveedor:</span>
                  <p className="text-gray-600">{product.PROVEEDOR}</p>
                </div>
              </div>

              {/* Controles de cantidad */}
              <div className="flex items-center gap-4 mb-6">
                <span className="font-semibold text-gray-700">Cantidad:</span>
                <div className="flex items-center border rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 hover:bg-gray-100 transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 min-w-[50px] text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product["STOK ACTUAL"], quantity + 1))}
                    className="px-3 py-2 hover:bg-gray-100 transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Botones de acción */}
              <div className="space-y-3">
                {/* Botón agregar al carrito */}
                <motion.button
                  onClick={handleAddToCart}
                  disabled={product["STOK ACTUAL"] === 0}
                  className={`w-full py-3 px-4 rounded-xl font-bold text-white shadow-lg transition-all ${
                    product["STOK ACTUAL"] === 0
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600'
                  }`}
                  whileHover={{ scale: product["STOK ACTUAL"] > 0 ? 1.02 : 1 }}
                  whileTap={{ scale: product["STOK ACTUAL"] > 0 ? 0.98 : 1 }}
                >
                  <ShoppingCart className="h-5 w-5 inline mr-2" />
                  {showAddedToCart ? '¡AGREGADO! ✓' : 'AGREGAR AL CARRITO'}
                </motion.button>

                {/* Botón WhatsApp */}
                <WhatsAppButton
                  message={whatsappMessage}
                  size="md"
                  className="w-full py-3"
                >
                  💬 CONSULTAR POR WHATSAPP
                </WhatsAppButton>

                {/* Botón wishlist */}
                <button
                  onClick={() => toggleWishlist(product)}
                  className={`w-full py-2 px-4 rounded-xl border transition-all ${
                    isInWishlist(product.PRODUCTO)
                      ? 'bg-red-50 border-red-200 text-red-600'
                      : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-red-50 hover:border-red-200 hover:text-red-600'
                  }`}
                >
                  <Heart className={`h-4 w-4 inline mr-2 ${isInWishlist(product.PRODUCTO) ? 'fill-current' : ''}`} />
                  {isInWishlist(product.PRODUCTO) ? 'En Lista de Deseos' : 'Agregar a Lista de Deseos'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Productos relacionados */}
        {product.CATEGORIA && (
          <div className="border-t p-6">
            <h3 className="text-lg font-semibold mb-4">También podrían interesarte:</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {['Gaming Headset Pro', 'Webcam 4K Ultra', 'Teclado Mecánico RGB', 'Mouse Inalámbrico'].map((item, index) => (
                <div key={index} className="text-center p-2">
                  <div className="w-16 h-16 bg-gray-200 rounded-lg mx-auto mb-2"></div>
                  <div className="text-sm font-semibold">{item}</div>
                  <div className="text-xs text-orange-600">Desde $50.000</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Modal>
  )
}

export default ProductModal
