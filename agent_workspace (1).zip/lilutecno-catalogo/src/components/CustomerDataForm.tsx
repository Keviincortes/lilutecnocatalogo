import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, MessageCircle, User, Phone, MapPin, MessageSquare, Send, CheckCircle, AlertTriangle } from 'lucide-react'
import { generateWhatsAppMessage, validateCustomerData, formatPhoneNumber, CustomerData, CartItem } from '../utils/whatsapp'
import { formatPrice } from '../utils/offers'
import { useCart } from '../contexts/CartContext'
import WhatsAppButton from './ui/WhatsAppButton'
import { useWhatsApp } from '../hooks/useWhatsApp'

interface CustomerDataFormProps {
  cartItems: CartItem[]
  total: number
  onBack: () => void
  onClose: () => void
}

const CustomerDataForm = ({ cartItems, total, onBack, onClose }: CustomerDataFormProps) => {
  const { clearCart } = useCart()
  const { sendToWhatsApp } = useWhatsApp()
  const [customerData, setCustomerData] = useState<CustomerData>({
    name: '',
    phone: '',
    address: '',
    comments: ''
  })
  const [errors, setErrors] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showPreview, setShowPreview] = useState(false)

  const handleInputChange = (field: keyof CustomerData, value: string) => {
    setCustomerData(prev => ({
      ...prev,
      [field]: value
    }))
    
    // Limpiar errores cuando el usuario empieza a escribir
    if (errors.length > 0) {
      setErrors([])
    }
  }

  const handlePhoneChange = (value: string) => {
    // Solo permitir números y algunos caracteres especiales
    const cleanValue = value.replace(/[^\d\s\-\(\)]/g, '')
    handleInputChange('phone', cleanValue)
  }

  const handleSubmit = () => {
    const validation = validateCustomerData(customerData)
    
    if (!validation.isValid) {
      setErrors(validation.errors)
      return
    }

    setShowPreview(true)
  }

  const handleSendWhatsApp = () => {
    setIsSubmitting(true)
    
    try {
      const message = generateWhatsAppMessage(cartItems, customerData)
      sendToWhatsApp(message)
      
      // Limpiar carrito después de enviar
      setTimeout(() => {
        clearCart()
        onClose()
        setIsSubmitting(false)
      }, 1000)
      
    } catch (error) {
      console.error('Error al enviar WhatsApp:', error)
      setIsSubmitting(false)
    }
  }

  const previewMessage = showPreview ? generateWhatsAppMessage(cartItems, customerData) : ''

  if (showPreview) {
    return (
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500 to-teal-500 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageCircle className="h-6 w-6" />
              <div>
                <h2 className="text-xl font-black">Vista Previa - WhatsApp</h2>
                <p className="text-green-100">Confirma tu pedido antes de enviar</p>
              </div>
            </div>
            <button
              onClick={() => setShowPreview(false)}
              className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Vista previa del mensaje */}
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6">
            <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Mensaje que se enviará a LiluTecno:
            </h3>
            <div className="bg-white p-4 rounded-lg border border-green-200">
              <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans leading-relaxed">
                {previewMessage}
              </pre>
            </div>
          </div>

          {/* Resumen del pedido */}
          <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
            <h3 className="font-bold text-blue-800 mb-3">📋 Resumen del pedido:</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Productos:</span>
                <span className="font-semibold">{cartItems.reduce((acc, item) => acc + item.quantity, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Cliente:</span>
                <span className="font-semibold">{customerData.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Teléfono:</span>
                <span className="font-semibold">{formatPhoneNumber(customerData.phone)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between text-lg">
                <span className="font-bold">Total:</span>
                <span className="font-black text-green-600">{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer con botones */}
        <div className="border-t p-6 bg-gray-50">
          <div className="space-y-3">
            <WhatsAppButton
              message={generateWhatsAppMessage(cartItems, customerData)}
              onClick={handleSendWhatsApp}
              disabled={isSubmitting}
              size="lg"
              className="w-full py-4 text-lg font-black"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="h-5 w-5" />
                  🚀 COMPRAR POR WHATSAPP
                </>
              )}
            </WhatsAppButton>

            <button
              onClick={() => setShowPreview(false)}
              className="w-full bg-gray-200 text-gray-700 py-3 px-4 rounded-xl font-bold hover:bg-gray-300 transition-colors"
              disabled={isSubmitting}
            >
              ← Editar datos
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <User className="h-6 w-6" />
            <div>
              <h2 className="text-xl font-black">Tus Datos</h2>
              <p className="text-blue-100">Para finalizar tu compra por WhatsApp</p>
            </div>
          </div>
          <button
            onClick={onBack}
            className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Formulario */}
      <div className="flex-1 p-6 overflow-y-auto">
        {/* Errores */}
        {errors.length > 0 && (
          <motion.div
            className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center gap-2 text-red-800 mb-2">
              <AlertTriangle className="h-5 w-5" />
              <span className="font-bold">Por favor corrige los siguientes errores:</span>
            </div>
            <ul className="list-disc list-inside text-red-700 text-sm space-y-1">
              {errors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </motion.div>
        )}

        <div className="space-y-6">
          {/* Nombre completo */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              <User className="h-4 w-4 inline mr-1" />
              Nombre completo *
            </label>
            <input
              type="text"
              value={customerData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Ej: Juan Pérez"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
              maxLength={50}
            />
          </div>

          {/* Teléfono */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              <Phone className="h-4 w-4 inline mr-1" />
              Número de teléfono *
            </label>
            <input
              type="tel"
              value={customerData.phone}
              onChange={(e) => handlePhoneChange(e.target.value)}
              placeholder="Ej: 300 123 4567"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
              maxLength={15}
            />
            <p className="text-xs text-gray-500 mt-1">
              Formato: celular (300 123 4567) o fijo (123 4567)
            </p>
          </div>

          {/* Dirección */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              <MapPin className="h-4 w-4 inline mr-1" />
              Ciudad / Dirección (opcional)
            </label>
            <input
              type="text"
              value={customerData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              placeholder="Ej: Bogotá, Carrera 15 #123-45"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
              maxLength={100}
            />
          </div>

          {/* Comentarios */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              <MessageSquare className="h-4 w-4 inline mr-1" />
              Comentarios adicionales (opcional)
            </label>
            <textarea
              value={customerData.comments}
              onChange={(e) => handleInputChange('comments', e.target.value)}
              placeholder="Ej: Preguntas sobre el producto, preferencias de entrega, etc."
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent resize-none"
              rows={3}
              maxLength={200}
            />
            <p className="text-xs text-gray-500 mt-1">
              {customerData.comments.length}/200 caracteres
            </p>
          </div>
        </div>

        {/* Resumen del pedido */}
        <div className="mt-6 bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-200 rounded-xl p-4">
          <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Resumen de tu pedido:
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Productos:</span>
              <span className="font-semibold">{cartItems.reduce((acc, item) => acc + item.quantity, 0)}</span>
            </div>
            <div className="flex justify-between text-lg border-t pt-2">
              <span className="font-bold">Total:</span>
              <span className="font-black text-green-600">{formatPrice(total)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t p-6 bg-gray-50">
        <div className="space-y-3">
          <motion.button
            onClick={handleSubmit}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-4 px-6 rounded-xl text-lg font-black shadow-lg flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <MessageCircle className="h-5 w-5" />
            Continuar Compra →
          </motion.button>

          <button
            onClick={onBack}
            className="w-full bg-gray-200 text-gray-700 py-3 px-4 rounded-xl font-bold hover:bg-gray-300 transition-colors"
          >
            ← Volver al carrito
          </button>
        </div>

        {/* Información de WhatsApp */}
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 text-green-800">
            <MessageCircle className="h-4 w-4" />
            <span className="text-sm font-semibold">
              Te conectaremos directamente con LiluTecno por WhatsApp
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CustomerDataForm
