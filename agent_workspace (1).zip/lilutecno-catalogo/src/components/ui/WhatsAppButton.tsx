import React from 'react'
import { MessageCircle } from 'lucide-react'
import { motion } from 'framer-motion'
import { useWhatsApp } from '../../hooks/useWhatsApp'

interface WhatsAppButtonProps {
  message: string
  children?: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  variant?: 'default' | 'outline' | 'floating'
  className?: string
  disabled?: boolean
  onClick?: () => void
}

const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({
  message,
  children,
  size = 'md',
  variant = 'default',
  className = '',
  disabled = false,
  onClick
}) => {
  const { sendToWhatsApp } = useWhatsApp()

  const handleClick = () => {
    if (disabled) return
    
    if (onClick) {
      onClick()
    }
    
    sendToWhatsApp(message)
  }

  const getSizeClass = () => {
    switch (size) {
      case 'sm':
        return 'whatsapp-button-sm'
      case 'lg':
        return 'whatsapp-button-lg'
      default:
        return ''
    }
  }

  const getVariantClass = () => {
    switch (variant) {
      case 'outline':
        return 'bg-transparent border-2 border-green-500 text-green-600 hover:bg-green-500 hover:text-white'
      case 'floating':
        return 'fixed bottom-6 right-6 z-50 rounded-full w-14 h-14 p-0 shadow-lg'
      default:
        return 'whatsapp-button'
    }
  }

  const buttonClass = `
    ${getVariantClass()}
    ${getSizeClass()}
    ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
    ${className}
  `.trim()

  const ButtonContent = () => (
    <>
      <MessageCircle className={`${size === 'sm' ? 'h-4 w-4' : size === 'lg' ? 'h-6 w-6' : 'h-5 w-5'}`} />
      {variant !== 'floating' && (children || 'COMPRAR POR WHATSAPP')}
    </>
  )

  if (variant === 'floating') {
    return (
      <motion.button
        className={buttonClass}
        onClick={handleClick}
        disabled={disabled}
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.95 }}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        aria-label="Contactar por WhatsApp"
      >
        <MessageCircle className="h-6 w-6" />
      </motion.button>
    )
  }

  return (
    <motion.button
      className={buttonClass}
      onClick={handleClick}
      disabled={disabled}
      whileHover={{ scale: 1.02, y: -1 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <ButtonContent />
    </motion.button>
  )
}

export default WhatsAppButton
