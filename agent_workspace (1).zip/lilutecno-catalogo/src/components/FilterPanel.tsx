import { useState, useMemo } from 'react'
import { Search, Filter, DollarSign, Package, Zap, Star, Percent, Heart, ShoppingCart } from 'lucide-react'
import { motion } from 'framer-motion'
import { Product, FilterState } from '../types/Product'
import { calculateOffer } from '../utils/offers'

interface FilterPanelProps {
  products: Product[]
  filters: FilterState
  onFilterChange: (filters: Partial<FilterState>) => void
}

const FilterPanel = ({ products, filters, onFilterChange }: FilterPanelProps) => {
  const [priceMin, setPriceMin] = useState(filters.priceRange[0].toString())
  const [priceMax, setPriceMax] = useState(filters.priceRange[1].toString())

  // Obtener categorías únicas con contadores
  const categories = useMemo(() => {
    const categoryMap = new Map<string, { count: number; offerCount: number }>()
    
    products.forEach(product => {
      const cat = product.CATEGORIA
      const offer = calculateOffer(product)
      const current = categoryMap.get(cat) || { count: 0, offerCount: 0 }
      categoryMap.set(cat, {
        count: current.count + 1,
        offerCount: current.offerCount + (offer.hasOffer ? 1 : 0)
      })
    })
    
    return Array.from(categoryMap.entries())
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [products])

  // Obtener rango de precios
  const priceRange = useMemo(() => {
    const prices = products.map(p => p["PRECIO DE VENTA"])
    return {
      min: Math.min(...prices),
      max: Math.max(...prices)
    }
  }, [products])

  // Estadísticas de ofertas
  const offerStats = useMemo(() => {
    const withOffers = products.filter(p => calculateOffer(p).hasOffer)
    const lowStock = products.filter(p => p["STOK ACTUAL"] > 0 && p["STOK ACTUAL"] <= 5)
    const superOffers = products.filter(p => calculateOffer(p).discountPercentage >= 30)
    
    return {
      withOffers: withOffers.length,
      lowStock: lowStock.length,
      superOffers: superOffers.length,
      inStock: products.filter(p => p["STOK ACTUAL"] > 0).length
    }
  }, [products])

  const handlePriceChange = () => {
    const min = parseInt(priceMin) || priceRange.min
    const max = parseInt(priceMax) || priceRange.max
    onFilterChange({ priceRange: [min, max] })
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(price)
  }

  const clearFilters = () => {
    onFilterChange({
      search: '',
      category: '',
      priceRange: [priceRange.min, priceRange.max],
      inStock: null
    })
    setPriceMin(priceRange.min.toString())
    setPriceMax(priceRange.max.toString())
  }

  const handleQuickFilter = (type: 'offers' | 'lowStock' | 'superOffers') => {
    switch (type) {
      case 'offers':
        // Filtrar productos con ofertas (margen > 30%)
        onFilterChange({ search: '' })
        break
      case 'lowStock':
        onFilterChange({ inStock: true })
        break
      case 'superOffers':
        // Para super ofertas, filtraremos por categorías con más ofertas
        const bestCategory = categories.find(c => c.offerCount > 0)
        if (bestCategory) {
          onFilterChange({ category: bestCategory.name })
        }
        break
    }
  }

  return (
    <motion.div 
      className="bg-white rounded-2xl shadow-2xl p-6 sticky top-4 border border-orange-200"
      initial={{ x: -50, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header con gradiente */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 -m-6 mb-6 p-6 rounded-t-2xl">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black text-white flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            🔍 Encuentra tu oferta
          </h2>
          <button
            onClick={clearFilters}
            className="text-sm text-orange-100 hover:text-white font-bold bg-white/20 px-3 py-1 rounded-lg"
          >
            Limpiar
          </button>
        </div>
      </div>

      {/* Filtros rápidos de ofertas */}
      <div className="mb-6">
        <h3 className="text-sm font-bold text-gray-700 mb-3">🔥 Filtros rápidos</h3>
        <div className="space-y-2">
          <motion.button
            className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-xl hover:from-red-100 hover:to-orange-100 transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleQuickFilter('superOffers')}
          >
            <div className="flex items-center">
              <Percent className="h-4 w-4 text-red-600 mr-2" />
              <span className="text-sm font-bold text-red-700">Super Ofertas</span>
            </div>
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              {offerStats.superOffers}
            </span>
          </motion.button>

          <motion.button
            className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl hover:from-yellow-100 hover:to-orange-100 transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleQuickFilter('lowStock')}
          >
            <div className="flex items-center">
              <Zap className="h-4 w-4 text-orange-600 mr-2" />
              <span className="text-sm font-bold text-orange-700">Últimas unidades</span>
            </div>
            <span className="bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              {offerStats.lowStock}
            </span>
          </motion.button>

          <motion.button
            className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-green-50 to-teal-50 border border-green-200 rounded-xl hover:from-green-100 hover:to-teal-100 transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onFilterChange({ inStock: true })}
          >
            <div className="flex items-center">
              <Package className="h-4 w-4 text-green-600 mr-2" />
              <span className="text-sm font-bold text-green-700">Disponible ahora</span>
            </div>
            <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              {offerStats.inStock}
            </span>
          </motion.button>
        </div>
      </div>

      {/* Búsqueda */}
      <div className="mb-6">
        <label className="block text-sm font-bold text-gray-700 mb-2">
          <Search className="h-4 w-4 inline mr-1" />
          Buscar Producto
        </label>
        <input
          type="text"
          value={filters.search}
          onChange={(e) => onFilterChange({ search: e.target.value })}
          placeholder="¿Qué estás buscando?"
          className="w-full px-4 py-3 border-2 border-orange-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent"
        />
      </div>

      {/* Categorías mejoradas */}
      <div className="mb-6">
        <label className="block text-sm font-bold text-gray-700 mb-3">
          📁 Categorías
        </label>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          <button
            onClick={() => onFilterChange({ category: '' })}
            className={`w-full text-left p-2 rounded-lg transition-all ${
              filters.category === '' 
                ? 'bg-orange-500 text-white' 
                : 'hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold">Todas las categorías</span>
              <span className="text-xs font-bold">{products.length}</span>
            </div>
          </button>
          
          {categories.map(category => (
            <button
              key={category.name}
              onClick={() => onFilterChange({ category: category.name })}
              className={`w-full text-left p-2 rounded-lg transition-all ${
                filters.category === category.name 
                  ? 'bg-orange-500 text-white' 
                  : 'hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">{category.name}</span>
                <div className="flex gap-1">
                  <span className="text-xs font-bold">{category.count}</span>
                  {category.offerCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-1 rounded">
                      {category.offerCount}🔥
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Rango de Precios mejorado */}
      <div className="mb-6">
        <label className="block text-sm font-bold text-gray-700 mb-2">
          <DollarSign className="h-4 w-4 inline mr-1" />
          💰 Rango de Precios
        </label>
        <div className="space-y-3">
          <div className="flex space-x-2">
            <div className="flex-1">
              <input
                type="number"
                value={priceMin}
                onChange={(e) => setPriceMin(e.target.value)}
                onBlur={handlePriceChange}
                placeholder="Mínimo"
                className="w-full px-3 py-2 border-2 border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 text-sm"
              />
            </div>
            <div className="flex-1">
              <input
                type="number"
                value={priceMax}
                onChange={(e) => setPriceMax(e.target.value)}
                onBlur={handlePriceChange}
                placeholder="Máximo"
                className="w-full px-3 py-2 border-2 border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 text-sm"
              />
            </div>
          </div>
          <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
            Rango: {formatPrice(priceRange.min)} - {formatPrice(priceRange.max)}
          </div>
        </div>
      </div>

      {/* Estadísticas súper atractivas */}
      <div className="bg-gradient-to-r from-gray-50 to-orange-50 p-4 rounded-xl border border-orange-200">
        <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center">
          <Star className="h-4 w-4 mr-1 text-orange-500" />
          🎯 Estadísticas en vivo
        </h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">🛍️ Total productos:</span>
            <span className="font-black text-orange-600">{products.length}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">🔥 En oferta:</span>
            <span className="font-black text-red-600">{offerStats.withOffers}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">✅ Disponibles:</span>
            <span className="font-black text-green-600">{offerStats.inStock}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">⚡ Pocas unidades:</span>
            <span className="font-black text-orange-600">{offerStats.lowStock}</span>
          </div>
        </div>
        
        {/* Mensaje motivacional */}
        <motion.div 
          className="mt-3 p-2 bg-gradient-to-r from-orange-400 to-red-400 text-white text-center rounded-lg text-xs font-bold"
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          🚀 ¡{offerStats.withOffers} productos en oferta te esperan!
        </motion.div>
      </div>
    </motion.div>
  )
}

export default FilterPanel
