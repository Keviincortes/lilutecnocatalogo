import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Package, 
  AlertTriangle, 
  TrendingUp, 
  FileText, 
  Download, 
  Upload,
  RefreshCw,
  BarChart3,
  DollarSign,
  Eye,
  Edit,
  Plus,
  Minus
} from 'lucide-react'
import useProducts from '../../hooks/useProducts'
import { formatPrice } from '../../utils/offers'

const InventoryManagement = () => {
  const { products, loading } = useProducts()
  const [selectedCategory, setSelectedCategory] = useState('')
  const [showBulkUpdate, setShowBulkUpdate] = useState(false)
  const [bulkUpdateType, setBulkUpdateType] = useState<'increase' | 'decrease' | 'set'>('increase')
  const [bulkUpdateValue, setBulkUpdateValue] = useState('')

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-orange-500/30 border-t-orange-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando inventario...</p>
        </div>
      </div>
    )
  }

  // Estadísticas de inventario
  const inventoryStats = {
    totalProducts: products.length,
    inStock: products.filter(p => p["STOK ACTUAL"] > 0).length,
    lowStock: products.filter(p => p["STOK ACTUAL"] > 0 && p["STOK ACTUAL"] <= 5).length,
    outOfStock: products.filter(p => p["STOK ACTUAL"] <= 0).length,
    totalValue: products.reduce((sum, p) => sum + (p["PRECIO DE VENTA"] * p["STOK ACTUAL"]), 0),
    averageStock: products.reduce((sum, p) => sum + p["STOK ACTUAL"], 0) / products.length
  }

  // Categorías únicas
  const categories = [...new Set(products.map(p => p.CATEGORIA))]

  // Productos filtrados
  const filteredProducts = selectedCategory 
    ? products.filter(p => p.CATEGORIA === selectedCategory)
    : products

  // Productos con alertas
  const alertProducts = products.filter(p => 
    p["STOK ACTUAL"] <= 5 || 
    p["STOK ACTUAL"] > 100 ||
    !p.imagen_principal
  )

  const handleBulkStockUpdate = () => {
    console.log('Bulk update:', bulkUpdateType, bulkUpdateValue)
    // Aquí iría la lógica para actualizar el stock masivamente
    setShowBulkUpdate(false)
  }

  const generateInventoryReport = () => {
    const reportData = {
      fecha: new Date().toISOString(),
      estadisticas: inventoryStats,
      productos: filteredProducts.map(p => ({
        nombre: p.PRODUCTO,
        categoria: p.CATEGORIA,
        stock: p["STOK ACTUAL"],
        precio: p["PRECIO DE VENTA"],
        valor_total: p["PRECIO DE VENTA"] * p["STOK ACTUAL"]
      }))
    }
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reporte_inventario_${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Gestión de Inventario</h1>
          <p className="text-gray-600 mt-1">Control avanzado de stock y productos</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button
            onClick={generateInventoryReport}
            className="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Reporte
          </button>
          <button
            onClick={() => setShowBulkUpdate(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Actualización Masiva
          </button>
        </div>
      </div>

      {/* Estadísticas de inventario */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Valor Total</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatPrice(inventoryStats.totalValue)}
              </p>
              <p className="text-sm text-green-600 mt-1">
                Stock promedio: {Math.round(inventoryStats.averageStock)}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg">
              <DollarSign className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">En Stock</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inventoryStats.inStock}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                de {inventoryStats.totalProducts} productos
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg">
              <Package className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Stock Bajo</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inventoryStats.lowStock}
              </p>
              <p className="text-sm text-orange-600 mt-1">
                Requieren atención
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 shadow-lg">
              <AlertTriangle className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Sin Stock</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inventoryStats.outOfStock}
              </p>
              <p className="text-sm text-red-600 mt-1">
                Necesitan restock
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-red-500 to-red-600 shadow-lg">
              <Package className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Filtrar por categoría
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="">Todas las categorías</option>
              {categories.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex space-x-2">
            <button className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all">
              <BarChart3 className="h-4 w-4 mr-2" />
              Ver Gráficos
            </button>
            <button className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all">
              <FileText className="h-4 w-4 mr-2" />
              Historial
            </button>
          </div>
        </div>
      </div>

      {/* Alertas */}
      {alertProducts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-yellow-50 border border-yellow-200 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
              <h3 className="text-lg font-bold text-yellow-800">
                Alertas de Inventario ({alertProducts.length})
              </h3>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {alertProducts.slice(0, 6).map((product, index) => (
              <div key={index} className="bg-white rounded-lg p-4 border border-yellow-200">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-sm truncate">
                      {product.PRODUCTO}
                    </h4>
                    <p className="text-xs text-gray-600">{product.CATEGORIA}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      product["STOK ACTUAL"] <= 0 
                        ? 'bg-red-100 text-red-800'
                        : product["STOK ACTUAL"] <= 5
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {product["STOK ACTUAL"]} unidades
                    </span>
                    <button className="text-blue-600 hover:text-blue-700">
                      <Edit className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {alertProducts.length > 6 && (
            <p className="text-sm text-yellow-700 mt-4 text-center">
              Y {alertProducts.length - 6} productos más con alertas...
            </p>
          )}
        </motion.div>
      )}

      {/* Modal de actualización masiva */}
      {showBulkUpdate && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-xl max-w-md w-full p-6"
          >
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Actualización Masiva de Stock
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de actualización
                </label>
                <select
                  value={bulkUpdateType}
                  onChange={(e) => setBulkUpdateType(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="increase">Aumentar stock</option>
                  <option value="decrease">Disminuir stock</option>
                  <option value="set">Establecer stock</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Valor
                </label>
                <input
                  type="number"
                  value={bulkUpdateValue}
                  onChange={(e) => setBulkUpdateValue(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="Ingresa el valor..."
                />
              </div>
              
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">
                  Esta acción afectará a <strong>{filteredProducts.length}</strong> productos
                  {selectedCategory && ` en la categoría "${selectedCategory}"`}.
                </p>
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={handleBulkStockUpdate}
                className="flex-1 bg-orange-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-600 transition-all"
              >
                Aplicar Cambios
              </button>
              <button
                onClick={() => setShowBulkUpdate(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-300 transition-all"
              >
                Cancelar
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Lista detallada de productos (muestra solo algunos para no sobrecargar) */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-bold text-gray-900">
            Productos {selectedCategory && `- ${selectedCategory}`}
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Mostrando {Math.min(filteredProducts.length, 10)} de {filteredProducts.length} productos
          </p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Producto
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Stock Actual
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Precio
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Valor Total
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredProducts.slice(0, 10).map((product, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-gray-900 truncate max-w-xs">
                        {product.PRODUCTO}
                      </div>
                      <div className="text-sm text-gray-500">{product.CATEGORIA}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      product["STOK ACTUAL"] <= 0 
                        ? 'bg-red-100 text-red-800'
                        : product["STOK ACTUAL"] <= 5
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {product["STOK ACTUAL"]}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {formatPrice(product["PRECIO DE VENTA"])}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    {formatPrice(product["PRECIO DE VENTA"] * product["STOK ACTUAL"])}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-700">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-700">
                        <Edit className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default InventoryManagement
