import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Users, 
  ShoppingCart,
  Eye,
  Calendar,
  Filter,
  Download,
  Zap
} from 'lucide-react'
import useProducts from '../../hooks/useProducts'
import { formatPrice } from '../../utils/offers'

const Analytics = () => {
  const { products, categories } = useProducts()
  const [timeRange, setTimeRange] = useState('30d')
  const [selectedMetric, setSelectedMetric] = useState('sales')

  // Datos simulados para analytics (en una implementación real vendrían de la base de datos)
  const analyticsData = {
    sales: {
      today: 850000,
      yesterday: 720000,
      thisWeek: 4200000,
      lastWeek: 3800000,
      thisMonth: 15600000,
      lastMonth: 14200000
    },
    visitors: {
      today: 245,
      yesterday: 198,
      thisWeek: 1420,
      lastWeek: 1280,
      thisMonth: 5340,
      lastMonth: 4890
    },
    orders: {
      today: 12,
      yesterday: 9,
      thisWeek: 68,
      lastWeek: 59,
      thisMonth: 234,
      lastMonth: 198
    },
    topProducts: [
      { name: "TELEVISOR 65\" SMART TV", sales: 45, revenue: 89550000 },
      { name: "TELEVISOR 55\" SMART TV", sales: 32, revenue: 44800000 },
      { name: "ALTAVOZ BLUETOOTH", sales: 28, revenue: 4200000 },
      { name: "AURICULARES GAMING", sales: 25, revenue: 3750000 },
      { name: "MOUSE GAMING", sales: 22, revenue: 1980000 }
    ],
    categoryPerformance: categories.map(cat => {
      const categoryProducts = products.filter(p => p.CATEGORIA === cat)
      const totalValue = categoryProducts.reduce((sum, p) => sum + (p["PRECIO DE VENTA"] * p["STOK ACTUAL"]), 0)
      const avgPrice = categoryProducts.reduce((sum, p) => sum + p["PRECIO DE VENTA"], 0) / categoryProducts.length || 0
      
      return {
        name: cat,
        products: categoryProducts.length,
        totalValue,
        avgPrice,
        growth: Math.random() * 40 - 10 // Simulado
      }
    }).sort((a, b) => b.totalValue - a.totalValue)
  }

  const getGrowthPercentage = (current: number, previous: number) => {
    return ((current - previous) / previous * 100).toFixed(1)
  }

  const getGrowthColor = (growth: number) => {
    return growth >= 0 ? 'text-green-600' : 'text-red-600'
  }

  const chartData = [
    { day: 'Lun', sales: 2400, orders: 24 },
    { day: 'Mar', sales: 1398, orders: 18 },
    { day: 'Mié', sales: 9800, orders: 42 },
    { day: 'Jue', sales: 3908, orders: 28 },
    { day: 'Vie', sales: 4800, orders: 35 },
    { day: 'Sáb', sales: 3800, orders: 31 },
    { day: 'Dom', sales: 4300, orders: 38 }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Analytics</h1>
          <p className="text-gray-600 mt-1">Análisis de ventas y rendimiento del negocio</p>
        </div>
        
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value="7d">Últimos 7 días</option>
            <option value="30d">Últimos 30 días</option>
            <option value="90d">Últimos 90 días</option>
            <option value="1y">Último año</option>
          </select>
          
          <button className="inline-flex items-center px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-all">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </button>
        </div>
      </div>

      {/* KPIs principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Ventas Hoy</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatPrice(analyticsData.sales.today)}
              </p>
              <p className={`text-sm mt-1 ${getGrowthColor(
                parseFloat(getGrowthPercentage(analyticsData.sales.today, analyticsData.sales.yesterday))
              )}`}>
                {getGrowthPercentage(analyticsData.sales.today, analyticsData.sales.yesterday)}% vs ayer
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg">
              <DollarSign className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pedidos Hoy</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {analyticsData.orders.today}
              </p>
              <p className={`text-sm mt-1 ${getGrowthColor(
                parseFloat(getGrowthPercentage(analyticsData.orders.today, analyticsData.orders.yesterday))
              )}`}>
                {getGrowthPercentage(analyticsData.orders.today, analyticsData.orders.yesterday)}% vs ayer
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg">
              <ShoppingCart className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Visitantes Hoy</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {analyticsData.visitors.today}
              </p>
              <p className={`text-sm mt-1 ${getGrowthColor(
                parseFloat(getGrowthPercentage(analyticsData.visitors.today, analyticsData.visitors.yesterday))
              )}`}>
                {getGrowthPercentage(analyticsData.visitors.today, analyticsData.visitors.yesterday)}% vs ayer
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 shadow-lg">
              <Users className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Ticket Promedio</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatPrice(analyticsData.sales.today / analyticsData.orders.today)}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Por pedido
              </p>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 shadow-lg">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Gráfico de ventas (simulado) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">Ventas de la Semana</h3>
            <div className="flex items-center space-x-2">
              <button className="p-2 text-gray-400 hover:text-gray-600">
                <BarChart3 className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            {chartData.map((item, index) => (
              <div key={item.day} className="flex items-center space-x-3">
                <div className="w-8 text-sm font-medium text-gray-600">
                  {item.day}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600">Ventas</span>
                    <span className="text-sm font-medium">{formatPrice(item.sales * 1000)}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(item.sales / 10000) * 100}%` }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="bg-gradient-to-r from-orange-500 to-red-500 h-2 rounded-full"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Top productos */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">Productos Más Vendidos</h3>
            <button className="text-sm text-orange-600 hover:text-orange-700 font-medium">
              Ver todos
            </button>
          </div>
          
          <div className="space-y-4">
            {analyticsData.topProducts.map((product, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 truncate max-w-xs">
                      {product.name}
                    </p>
                    <p className="text-xs text-gray-500">{product.sales} ventas</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-gray-900">
                    {formatPrice(product.revenue)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Rendimiento por categorías */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
      >
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-bold text-gray-900">Rendimiento por Categorías</h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Categoría
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Productos
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Valor Total
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Precio Promedio
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Crecimiento
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {analyticsData.categoryPerformance.slice(0, 8).map((category, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">
                      {category.name}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {category.products}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    {formatPrice(category.totalValue)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {formatPrice(category.avgPrice)}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      category.growth >= 0
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {category.growth >= 0 ? '+' : ''}{category.growth.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Acciones rápidas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
      >
        <h3 className="text-lg font-bold text-gray-900 mb-4">Acciones Rápidas</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="flex items-center justify-center space-x-2 p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg hover:from-blue-100 hover:to-blue-200 transition-all">
            <Eye className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-700">Ver Reportes</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 p-4 bg-gradient-to-r from-green-50 to-green-100 rounded-lg hover:from-green-100 hover:to-green-200 transition-all">
            <TrendingUp className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-700">Análisis Avanzado</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg hover:from-purple-100 hover:to-purple-200 transition-all">
            <Calendar className="h-5 w-5 text-purple-600" />
            <span className="text-sm font-medium text-purple-700">Programar Reporte</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg hover:from-orange-100 hover:to-orange-200 transition-all">
            <Zap className="h-5 w-5 text-orange-600" />
            <span className="text-sm font-medium text-orange-700">Insights IA</span>
          </button>
        </div>
      </motion.div>
    </div>
  )
}

export default Analytics
