import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  Save, 
  Upload, 
  Image as ImageIcon, 
  DollarSign, 
  Package, 
  Tag,
  User,
  FileText,
  AlertCircle
} from 'lucide-react';
import { Product } from '../../types/Product';
import useProducts from '../../hooks/useProducts';
import SimpleImageManager from './SimpleImageManager';

interface ProductFormProps {
  product?: Product | null;
  onClose: () => void;
  onSave: () => void;
}

const ProductForm = ({ product, onClose, onSave }: ProductFormProps) => {
  const { addProduct, updateProduct, categories, providers } = useProducts();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [formData, setFormData] = useState({
    producto: '',
    descripcion: '',
    categoria: '',
    stockActual: 0,
    precioVenta: 0,
    costo: 0,
    proveedor: '',
    observaciones: '',
    imagenPrincipal: '',
    imagenes: [] as string[]
  });

  // Llenar formulario si estamos editando
  useEffect(() => {
    if (product) {
      setFormData({
        producto: product.PRODUCTO,
        descripcion: product.DESCRICION || '',
        categoria: product.CATEGORIA,
        stockActual: product["STOK ACTUAL"],
        precioVenta: product["PRECIO DE VENTA"],
        costo: product.COSTO,
        proveedor: product.PROVEEDOR,
        observaciones: product.OBSERVACIONES || '',
        imagenPrincipal: product.imagen_principal || '',
        imagenes: [product["IMAGEN 1"], product["IMAGEN 2"], product["IMAGEN 3"], product["IMAGEN 4"], product["IMAGEN 5"]].filter(Boolean)
      });
    }
  }, [product]);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Limpiar error del campo cuando se modifica
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.producto.trim()) {
      newErrors.producto = 'El nombre del producto es requerido';
    }
    
    if (!formData.categoria.trim()) {
      newErrors.categoria = 'La categoría es requerida';
    }
    
    if (formData.precioVenta <= 0) {
      newErrors.precioVenta = 'El precio de venta debe ser mayor a 0';
    }
    
    if (formData.costo < 0) {
      newErrors.costo = 'El costo no puede ser negativo';
    }
    
    if (formData.stockActual < 0) {
      newErrors.stockActual = 'El stock no puede ser negativo';
    }

    if (!formData.proveedor.trim()) {
      newErrors.proveedor = 'El proveedor es requerido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const productData = {
        PRODUCTO: formData.producto,
        DESCRICION: formData.descripcion,
        CATEGORIA: formData.categoria,
        "STOCK INICIAL": product ? product["STOCK INICIAL"] : 0,
        ENTRADAS: product ? product.ENTRADAS : 0,
        SALIDAS: product ? product.SALIDAS : 0,
        "STOK ACTUAL": formData.stockActual,
        "PRECIO DE VENTA": formData.precioVenta,
        COSTO: formData.costo,
        PROVEEDOR: formData.proveedor,
        OBSERVACIONES: formData.observaciones,
        imagen_principal: formData.imagenPrincipal,
        "IMAGEN 1": product ? product["IMAGEN 1"] : "",
        "IMAGEN 2": product ? product["IMAGEN 2"] : "",
        "IMAGEN 3": product ? product["IMAGEN 3"] : "",
        "IMAGEN 4": product ? product["IMAGEN 4"] : "",
        "IMAGEN 5": product ? product["IMAGEN 5"] : ""
      };

      let success;
      if (product) {
        success = await updateProduct(product.PRODUCTO, productData);
      } else {
        success = await addProduct(productData);
      }

      if (success) {
        onSave();
      } else {
        setErrors({ general: 'Error al guardar el producto' });
      }
    } catch (error) {
      setErrors({ general: 'Error inesperado al guardar' });
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // En una implementación real, aquí subirías la imagen a un servidor
      // Por ahora, solo ponemos el nombre del archivo
      handleInputChange('imagenPrincipal', `imagenes_productos/${file.name}`);
    }
  };



  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gray-50">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {product ? 'Editar Producto' : 'Agregar Producto'}
            </h2>
            <p className="text-gray-600">
              {product ? 'Modifica la información del producto' : 'Completa los datos del nuevo producto'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Formulario */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Error general */}
          {errors.general && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              {errors.general}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Información básica */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Información Básica
              </h3>

              {/* Nombre del producto */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre del Producto *
                </label>
                <input
                  type="text"
                  value={formData.producto}
                  onChange={(e) => handleInputChange('producto', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                    errors.producto ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="Ej: Televisor 65 pulgadas Smart TV"
                />
                {errors.producto && (
                  <p className="text-red-500 text-sm mt-1">{errors.producto}</p>
                )}
              </div>

              {/* Categoría */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Categoría *
                </label>
                <select
                  value={formData.categoria}
                  onChange={(e) => handleInputChange('categoria', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                    errors.categoria ? 'border-red-500' : 'border-gray-300'
                  }`}
                >
                  <option value="">Seleccionar categoría</option>
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                  <option value="nueva">+ Nueva categoría</option>
                </select>
                {errors.categoria && (
                  <p className="text-red-500 text-sm mt-1">{errors.categoria}</p>
                )}
              </div>

              {/* Proveedor */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Proveedor *
                </label>
                <select
                  value={formData.proveedor}
                  onChange={(e) => handleInputChange('proveedor', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                    errors.proveedor ? 'border-red-500' : 'border-gray-300'
                  }`}
                >
                  <option value="">Seleccionar proveedor</option>
                  {providers.map(prov => (
                    <option key={prov} value={prov}>{prov}</option>
                  ))}
                  <option value="nuevo">+ Nuevo proveedor</option>
                </select>
                {errors.proveedor && (
                  <p className="text-red-500 text-sm mt-1">{errors.proveedor}</p>
                )}
              </div>

              {/* Stock actual */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stock Actual
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.stockActual}
                  onChange={(e) => handleInputChange('stockActual', parseInt(e.target.value) || 0)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                    errors.stockActual ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="0"
                />
                {errors.stockActual && (
                  <p className="text-red-500 text-sm mt-1">{errors.stockActual}</p>
                )}
              </div>
            </div>

            {/* Precios e imagen */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <DollarSign className="h-5 w-5 mr-2" />
                Precios e Imagen
              </h3>

              {/* Precio de venta */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Precio de Venta *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formData.precioVenta}
                    onChange={(e) => handleInputChange('precioVenta', parseInt(e.target.value) || 0)}
                    className={`w-full pl-8 pr-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                      errors.precioVenta ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="0"
                  />
                </div>
                {errors.precioVenta && (
                  <p className="text-red-500 text-sm mt-1">{errors.precioVenta}</p>
                )}
              </div>

              {/* Costo */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Costo
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formData.costo}
                    onChange={(e) => handleInputChange('costo', parseInt(e.target.value) || 0)}
                    className={`w-full pl-8 pr-3 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none ${
                      errors.costo ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="0"
                  />
                </div>
                {errors.costo && (
                  <p className="text-red-500 text-sm mt-1">{errors.costo}</p>
                )}
              </div>

              {/* Margen de ganancia (calculado) */}
              {formData.precioVenta > 0 && formData.costo > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-sm text-green-700">
                    <strong>Margen de ganancia:</strong>{' '}
                    {(((formData.precioVenta - formData.costo) / formData.precioVenta) * 100).toFixed(1)}%
                  </p>
                  <p className="text-sm text-green-600">
                    Ganancia por unidad: ${(formData.precioVenta - formData.costo).toLocaleString()}
                  </p>
                </div>
              )}

              {/* Gestión de imágenes múltiples */}
              <div>
                <SimpleImageManager
                  images={formData.imagenes}
                  onChange={(images) => setFormData(prev => ({ ...prev, imagenes: images }))}
                  maxImages={5}
                />
              </div>
            </div>
          </div>

          {/* Descripción */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="h-4 w-4 inline mr-1" />
              Descripción del Producto
            </label>
            <textarea
              value={formData.descripcion}
              onChange={(e) => handleInputChange('descripcion', e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none resize-none"
              placeholder="Descripción detallada del producto, características, especificaciones técnicas..."
            />
          </div>

          {/* Observaciones */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Observaciones (Opcional)
            </label>
            <textarea
              value={formData.observaciones}
              onChange={(e) => handleInputChange('observaciones', e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none resize-none"
              placeholder="Notas adicionales, comentarios internos..."
            />
          </div>
        </form>

        {/* Footer con botones */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <p className="text-sm text-gray-500">
            * Campos requeridos
          </p>
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium text-gray-700"
              disabled={loading}
            >
              Cancelar
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading}
              className={`px-6 py-2 rounded-lg font-medium text-white transition-all ${
                loading
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg'
              }`}
            >
              {loading ? (
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                  Guardando...
                </div>
              ) : (
                <>
                  <Save className="h-4 w-4 inline mr-2" />
                  {product ? 'Actualizar' : 'Crear'} Producto
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ProductForm;
