import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  Upload, 
  X, 
  Image as ImageIcon, 
  Star,
  Plus
} from 'lucide-react';

interface SimpleImageManagerProps {
  images: string[];
  onChange: (images: string[]) => void;
  maxImages?: number;
  disabled?: boolean;
}

const SimpleImageManager: React.FC<SimpleImageManagerProps> = ({ 
  images = [], 
  onChange, 
  maxImages = 5,
  disabled = false
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (files: FileList | null) => {
    if (!files || disabled) return;

    const remainingSlots = maxImages - images.length;
    const newImages = [...images];

    Array.from(files).slice(0, remainingSlots).forEach((file) => {
      // Validar tipo de archivo
      if (!file.type.startsWith('image/')) {
        alert(`${file.name} no es un archivo de imagen válido`);
        return;
      }

      // Validar tamaño (máximo 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert(`${file.name} es demasiado grande. Máximo 5MB por imagen.`);
        return;
      }

      // Convertir a base64 o URL temporal
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          newImages.push(e.target.result as string);
          onChange([...newImages]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    if (disabled) return;
    const newImages = images.filter((_, i) => i !== index);
    onChange(newImages);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (disabled) return;
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleClick = () => {
    if (!disabled) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-gray-700">
          Imágenes del Producto ({images.length}/{maxImages})
        </p>
        {images.length > 0 && (
          <p className="text-xs text-gray-500">
            La primera imagen será la principal
          </p>
        )}
      </div>

      {/* Drop Zone */}
      {images.length < maxImages && (
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onClick={handleClick}
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
            disabled 
              ? 'border-gray-200 bg-gray-50 cursor-not-allowed' 
              : 'border-gray-300 hover:border-orange-400 hover:bg-orange-50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*"
            onChange={(e) => handleFileSelect(e.target.files)}
            className="hidden"
            disabled={disabled}
          />
          
          <div className="space-y-2">
            <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${
              disabled ? 'bg-gray-200' : 'bg-orange-100'
            }`}>
              <Upload className={`h-6 w-6 ${disabled ? 'text-gray-400' : 'text-orange-500'}`} />
            </div>
            <div>
              <p className={`font-medium ${disabled ? 'text-gray-400' : 'text-gray-700'}`}>
                Arrastra imágenes aquí o haz clic para seleccionar
              </p>
              <p className={`text-sm ${disabled ? 'text-gray-300' : 'text-gray-500'}`}>
                PNG, JPG, GIF hasta 5MB cada una
              </p>
              <p className={`text-xs ${disabled ? 'text-gray-300' : 'text-gray-400'}`}>
                Máximo {maxImages} imágenes
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Preview de Imágenes */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="relative group"
            >
              <div className="aspect-square rounded-lg overflow-hidden bg-gray-100 border-2 border-gray-200">
                <img
                  src={image}
                  alt={`Imagen ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Indicador de Imagen Principal */}
              {index === 0 && (
                <div className="absolute top-2 left-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full flex items-center space-x-1">
                  <Star className="h-3 w-3 fill-current" />
                  <span>Principal</span>
                </div>
              )}

              {/* Botón Eliminar */}
              {!disabled && (
                <button
                  onClick={() => removeImage(index)}
                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                  title="Eliminar imagen"
                >
                  <X className="h-4 w-4" />
                </button>
              )}

              {/* Número de imagen */}
              <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                {index + 1}
              </div>
            </motion.div>
          ))}

          {/* Botón Agregar Más */}
          {images.length < maxImages && !disabled && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="aspect-square rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-orange-400 hover:bg-orange-50 transition-all"
              onClick={handleClick}
            >
              <div className="text-center">
                <Plus className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-xs text-gray-500">Agregar</p>
              </div>
            </motion.div>
          )}
        </div>
      )}

      {/* Información adicional */}
      {images.length === 0 && (
        <div className="text-center py-4">
          <ImageIcon className="h-12 w-12 text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-500">
            No hay imágenes agregadas
          </p>
        </div>
      )}
    </div>
  );
};

export default SimpleImageManager;
