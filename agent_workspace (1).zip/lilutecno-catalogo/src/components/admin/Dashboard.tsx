import { motion } from 'framer-motion';
import { 
  Package, 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  Eye,
  ShoppingCart,
  Users,
  FolderOpen,
  Clock,
  Star
} from 'lucide-react';
import useProducts from '../../hooks/useProducts';
import { formatPrice } from '../../utils/offers';

const Dashboard = () => {
  const { products, loading, categories, providers } = useProducts();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-orange-500/30 border-t-orange-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  // Cálculos estadísticos
  const totalProducts = products.length;
  const inStockProducts = products.filter(p => p["STOK ACTUAL"] > 0).length;
  const outOfStockProducts = totalProducts - inStockProducts;
  const totalInventoryValue = products.reduce((sum, p) => sum + (p["PRECIO DE VENTA"] * p["STOK ACTUAL"]), 0);
  const averagePrice = totalProducts > 0 ? products.reduce((sum, p) => sum + p["PRECIO DE VENTA"], 0) / totalProducts : 0;
  const averageMargin = totalProducts > 0 
    ? products.reduce((sum, p) => {
        const margin = p["PRECIO DE VENTA"] > 0 ? ((p["PRECIO DE VENTA"] - p.COSTO) / p["PRECIO DE VENTA"]) * 100 : 0;
        return sum + margin;
      }, 0) / totalProducts 
    : 0;

  // Productos con stock bajo (menos de 5 unidades)
  const lowStockProducts = products.filter(p => p["STOK ACTUAL"] > 0 && p["STOK ACTUAL"] <= 5);

  // Top categorías por cantidad de productos
  const categoryStats = categories.map(cat => ({
    name: cat,
    count: products.filter(p => p.CATEGORIA === cat).length,
    value: products.filter(p => p.CATEGORIA === cat).reduce((sum, p) => sum + (p["PRECIO DE VENTA"] * p["STOK ACTUAL"]), 0)
  })).sort((a, b) => b.count - a.count);

  const stats = [
    {
      title: 'Total Productos',
      value: totalProducts.toLocaleString(),
      icon: Package,
      color: 'from-blue-500 to-blue-600',
      change: '+12%',
      changeType: 'positive'
    },
    {
      title: 'Valor Inventario',
      value: formatPrice(totalInventoryValue),
      icon: DollarSign,
      color: 'from-green-500 to-green-600',
      change: '+8.2%',
      changeType: 'positive'
    },
    {
      title: 'En Stock',
      value: inStockProducts.toLocaleString(),
      icon: TrendingUp,
      color: 'from-emerald-500 to-emerald-600',
      change: '+5.1%',
      changeType: 'positive'
    },
    {
      title: 'Sin Stock',
      value: outOfStockProducts.toLocaleString(),
      icon: AlertTriangle,
      color: 'from-red-500 to-red-600',
      change: '-2.3%',
      changeType: 'negative'
    }
  ];

  const quickStats = [
    {
      label: 'Precio Promedio',
      value: formatPrice(averagePrice),
      icon: DollarSign
    },
    {
      label: 'Margen Promedio',
      value: `${averageMargin.toFixed(1)}%`,
      icon: TrendingUp
    },
    {
      label: 'Categorías',
      value: categories.length.toString(),
      icon: FolderOpen
    },
    {
      label: 'Proveedores',
      value: providers.length.toString(),
      icon: Users
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Resumen general del catálogo</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-sm font-medium">
            <Clock className="h-4 w-4 inline mr-2" />
            Última actualización: hace 5 min
          </button>
        </div>
      </div>

      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change}
                    </span>
                    <span className="text-sm text-gray-500 ml-1">vs mes anterior</span>
                  </div>
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.color} shadow-lg`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 + (index * 0.05) }}
              className="bg-white rounded-lg border border-gray-200 p-4"
            >
              <div className="flex items-center space-x-3">
                <Icon className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-lg font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Productos con stock bajo */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200"
        >
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-gray-900">Stock Bajo</h3>
              <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-1 rounded-full">
                {lowStockProducts.length} productos
              </span>
            </div>
          </div>
          <div className="p-6">
            {lowStockProducts.length > 0 ? (
              <div className="space-y-3">
                {lowStockProducts.slice(0, 5).map((product, index) => (
                  <div key={index} className="flex items-center justify-between py-2">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {product.PRODUCTO}
                      </p>
                      <p className="text-xs text-gray-500">{product.CATEGORIA}</p>
                    </div>
                    <div className="text-right">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        {product["STOK ACTUAL"]} unidades
                      </span>
                    </div>
                  </div>
                ))}
                {lowStockProducts.length > 5 && (
                  <p className="text-sm text-gray-500 text-center pt-2">
                    Y {lowStockProducts.length - 5} productos más...
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Package className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-500">No hay productos con stock bajo</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Top categorías */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200"
        >
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-900">Categorías Principales</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {categoryStats.slice(0, 5).map((category, index) => (
                <div key={category.name} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center text-white text-xs font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{category.name}</p>
                      <p className="text-xs text-gray-500">{formatPrice(category.value)}</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-gray-600">
                    {category.count} productos
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Acciones rápidas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
      >
        <h3 className="text-lg font-bold text-gray-900 mb-4">Acciones Rápidas</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all">
            <Package className="h-5 w-5 text-orange-500" />
            <span className="text-sm font-medium">Agregar Producto</span>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all">
            <Eye className="h-5 w-5 text-blue-500" />
            <span className="text-sm font-medium">Ver Catálogo</span>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all">
            <ShoppingCart className="h-5 w-5 text-green-500" />
            <span className="text-sm font-medium">Gestionar Stock</span>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all">
            <Star className="h-5 w-5 text-yellow-500" />
            <span className="text-sm font-medium">Productos Destacados</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
