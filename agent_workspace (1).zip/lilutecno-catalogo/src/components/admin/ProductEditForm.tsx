import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  Save, 
  Upload, 
  Image as ImageIcon, 
  DollarSign, 
  Package, 
  Tag,
  User,
  FileText,
  AlertCircle,
  Check,
  Loader2
} from 'lucide-react';
import { Product } from '../../types/Product';
import SimpleImageManager from './SimpleImageManager';
import { formatPrice } from '../../utils/offers';

interface ProductEditFormProps {
  product?: Product | null;
  onSave: (productData: any) => Promise<void>;
  onCancel: () => void;
  isOpen: boolean;
}

interface FormData {
  PRODUCTO: string;
  DESCRICION: string;
  CATEGORIA: string;
  'STOK ACTUAL': number;
  'PRECIO DE VENTA': number;
  COSTO: number;
  PROVEEDOR: string;
  OBSERVACIONES: string;
  imagenes: string[];
}

const ProductEditForm: React.FC<ProductEditFormProps> = ({
  product,
  onSave,
  onCancel,
  isOpen
}) => {
  const [formData, setFormData] = useState<FormData>({
    PRODUCTO: '',
    DESCRICION: '',
    CATEGORIA: '',
    'STOK ACTUAL': 0,
    'PRECIO DE VENTA': 0,
    COSTO: 0,
    PROVEEDOR: '',
    OBSERVACIONES: '',
    imagenes: []
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Categorías disponibles
  const categories = [
    'TELEVISOR',
    'ENTRETENIMIENTO', 
    'ACCESORIOS',
    'AUDIO',
    'GAMING',
    'PROYECTORES',
    'CABLES',
    'NETWORKING'
  ];

  // Cargar datos del producto si estamos editando
  useEffect(() => {
    if (product) {
      setFormData({
        PRODUCTO: product.PRODUCTO || '',
        DESCRICION: product.DESCRICION || '',
        CATEGORIA: product.CATEGORIA || '',
        'STOK ACTUAL': product['STOK ACTUAL'] || 0,
        'PRECIO DE VENTA': product['PRECIO DE VENTA'] || 0,
        COSTO: product.COSTO || 0,
        PROVEEDOR: product.PROVEEDOR || '',
        OBSERVACIONES: product.OBSERVACIONES || '',
        imagenes: [
          product['IMAGEN 1'],
          product['IMAGEN 2'], 
          product['IMAGEN 3'],
          product['IMAGEN 4'],
          product['IMAGEN 5']
        ].filter(Boolean)
      });
    } else {
      // Resetear para nuevo producto
      setFormData({
        PRODUCTO: '',
        DESCRICION: '',
        CATEGORIA: '',
        'STOK ACTUAL': 0,
        'PRECIO DE VENTA': 0,
        COSTO: 0,
        PROVEEDOR: '',
        OBSERVACIONES: '',
        imagenes: []
      });
    }
    setErrors({});
    setSaved(false);
  }, [product, isOpen]);

  const handleInputChange = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Limpiar error del campo
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.PRODUCTO.trim()) {
      newErrors.PRODUCTO = 'El nombre del producto es requerido';
    }

    if (!formData.CATEGORIA.trim()) {
      newErrors.CATEGORIA = 'La categoría es requerida';
    }

    if (formData['PRECIO DE VENTA'] <= 0) {
      newErrors['PRECIO DE VENTA'] = 'El precio de venta debe ser mayor a 0';
    }

    if (formData.COSTO < 0) {
      newErrors.COSTO = 'El costo no puede ser negativo';
    }

    if (formData['STOK ACTUAL'] < 0) {
      newErrors['STOK ACTUAL'] = 'El stock no puede ser negativo';
    }

    if (!formData.PROVEEDOR.trim()) {
      newErrors.PROVEEDOR = 'El proveedor es requerido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      // Preparar datos con imágenes en el formato correcto
      const productData = {
        ...formData,
        'IMAGEN 1': formData.imagenes[0] || '',
        'IMAGEN 2': formData.imagenes[1] || '',
        'IMAGEN 3': formData.imagenes[2] || '',
        'IMAGEN 4': formData.imagenes[3] || '',
        'IMAGEN 5': formData.imagenes[4] || '',
        imagen_principal: formData.imagenes[0] || '',
        // Campos calculados
        margen: formData['PRECIO DE VENTA'] > 0 
          ? ((formData['PRECIO DE VENTA'] - formData.COSTO) / formData['PRECIO DE VENTA'] * 100).toFixed(1)
          : '0',
        // Mantener campos originales si existen
        ...(product && {
          'Unnamed: 0': product['Unnamed: 0'],
          'STOCK INICIAL': product['STOCK INICIAL'],
          'ENTRADAS': product['ENTRADAS'],
          'SALIDAS': product['SALIDAS']
        })
      };

      await onSave(productData);
      setSaved(true);
      
      // Cerrar después de mostrar confirmación
      setTimeout(() => {
        onCancel();
      }, 1500);
      
    } catch (error) {
      console.error('Error al guardar producto:', error);
      setErrors({ general: 'Error al guardar el producto. Inténtalo de nuevo.' });
    } finally {
      setSaving(false);
    }
  };

  // Calcular margen en tiempo real
  const margin = formData['PRECIO DE VENTA'] > 0 
    ? ((formData['PRECIO DE VENTA'] - formData.COSTO) / formData['PRECIO DE VENTA'] * 100).toFixed(1)
    : '0';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {product ? 'Editar Producto' : 'Nuevo Producto'}
              </h2>
              <p className="text-gray-500">
                {product ? 'Modifica los datos del producto' : 'Completa la información del nuevo producto'}
              </p>
            </div>
            <button
              onClick={onCancel}
              disabled={saving}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-8">
          {/* Error general */}
          {errors.general && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              <span className="text-red-700">{errors.general}</span>
            </div>
          )}

          {/* Mensaje de éxito */}
          {saved && (
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center space-x-2"
            >
              <Check className="h-5 w-5 text-green-500" />
              <span className="text-green-700">¡Producto guardado exitosamente!</span>
            </motion.div>
          )}

          {/* Información Básica */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Información Básica</span>
            </h3>

            {/* Nombre del Producto */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre del Producto *
              </label>
              <input
                type="text"
                value={formData.PRODUCTO}
                onChange={(e) => handleInputChange('PRODUCTO', e.target.value)}
                placeholder="Ej: Samsung Smart TV 65 pulgadas 4K"
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                  errors.PRODUCTO ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                disabled={saving}
              />
              {errors.PRODUCTO && (
                <p className="mt-1 text-sm text-red-600">{errors.PRODUCTO}</p>
              )}
            </div>

            {/* Descripción */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descripción
              </label>
              <textarea
                rows={4}
                value={formData.DESCRICION}
                onChange={(e) => handleInputChange('DESCRICION', e.target.value)}
                placeholder="Describe las características principales del producto..."
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all resize-none ${
                  errors.DESCRICION ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                disabled={saving}
              />
              {errors.DESCRICION && (
                <p className="mt-1 text-sm text-red-600">{errors.DESCRICION}</p>
              )}
            </div>

            {/* Categoría */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Categoría *
              </label>
              <select
                value={formData.CATEGORIA}
                onChange={(e) => handleInputChange('CATEGORIA', e.target.value)}
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                  errors.CATEGORIA ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                disabled={saving}
              >
                <option value="">Seleccionar categoría</option>
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              {errors.CATEGORIA && (
                <p className="mt-1 text-sm text-red-600">{errors.CATEGORIA}</p>
              )}
            </div>
          </div>

          {/* Información Comercial */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <DollarSign className="h-5 w-5" />
              <span>Información Comercial</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Stock */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Stock Actual *
                </label>
                <input
                  type="number"
                  value={formData['STOK ACTUAL']}
                  onChange={(e) => handleInputChange('STOK ACTUAL', parseInt(e.target.value) || 0)}
                  min="0"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                    errors['STOK ACTUAL'] ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                  disabled={saving}
                />
                {errors['STOK ACTUAL'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['STOK ACTUAL']}</p>
                )}
              </div>

              {/* Precio de Venta */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Precio de Venta *
                </label>
                <input
                  type="number"
                  value={formData['PRECIO DE VENTA']}
                  onChange={(e) => handleInputChange('PRECIO DE VENTA', parseInt(e.target.value) || 0)}
                  min="0"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                    errors['PRECIO DE VENTA'] ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                  disabled={saving}
                />
                {errors['PRECIO DE VENTA'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['PRECIO DE VENTA']}</p>
                )}
                <p className="mt-1 text-sm text-gray-500">
                  {formatPrice(formData['PRECIO DE VENTA'])}
                </p>
              </div>

              {/* Costo */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Costo *
                </label>
                <input
                  type="number"
                  value={formData.COSTO}
                  onChange={(e) => handleInputChange('COSTO', parseInt(e.target.value) || 0)}
                  min="0"
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                    errors.COSTO ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                  disabled={saving}
                />
                {errors.COSTO && (
                  <p className="mt-1 text-sm text-red-600">{errors.COSTO}</p>
                )}
                <p className="mt-1 text-sm text-gray-500">
                  {formatPrice(formData.COSTO)}
                </p>
              </div>
            </div>

            {/* Margen calculado */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-blue-900">Margen de Ganancia:</span>
                <span className={`text-lg font-bold ${
                  parseFloat(margin) > 30 ? 'text-green-600' : 
                  parseFloat(margin) > 15 ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  {margin}%
                </span>
              </div>
              <p className="text-xs text-blue-700 mt-1">
                Ganancia: {formatPrice(formData['PRECIO DE VENTA'] - formData.COSTO)}
              </p>
            </div>
          </div>

          {/* Información del Proveedor */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Información del Proveedor</span>
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Proveedor *
              </label>
              <input
                type="text"
                value={formData.PROVEEDOR}
                onChange={(e) => handleInputChange('PROVEEDOR', e.target.value)}
                placeholder="Nombre del proveedor"
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all ${
                  errors.PROVEEDOR ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                disabled={saving}
              />
              {errors.PROVEEDOR && (
                <p className="mt-1 text-sm text-red-600">{errors.PROVEEDOR}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Observaciones
              </label>
              <textarea
                rows={3}
                value={formData.OBSERVACIONES}
                onChange={(e) => handleInputChange('OBSERVACIONES', e.target.value)}
                placeholder="Notas adicionales, condiciones especiales, etc."
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all resize-none"
                disabled={saving}
              />
            </div>
          </div>

          {/* Gestión de Imágenes */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <ImageIcon className="h-5 w-5" />
              <span>Imágenes del Producto</span>
            </h3>

            <SimpleImageManager
              images={formData.imagenes}
              onChange={(images) => handleInputChange('imagenes', images)}
              maxImages={5}
              disabled={saving}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 rounded-b-2xl">
          <div className="flex justify-end space-x-4">
            <button
              onClick={onCancel}
              disabled={saving}
              className="px-6 py-3 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl hover:from-orange-600 hover:to-red-600 transition-all disabled:opacity-50 flex items-center space-x-2"
            >
              {saving ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  <span>Guardando...</span>
                </>
              ) : (
                <>
                  <Save className="h-5 w-5" />
                  <span>{product ? 'Actualizar Producto' : 'Crear Producto'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProductEditForm;
