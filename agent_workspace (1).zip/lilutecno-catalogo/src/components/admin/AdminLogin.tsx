import { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Eye, EyeOff, Lock, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const AdminLogin = () => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simular un pequeño delay para la autenticación
    await new Promise(resolve => setTimeout(resolve, 1000));

    const success = login(password);
    
    if (!success) {
      setError('Contraseña incorrecta. Inténtalo de nuevo.');
      setPassword('');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        {/* Header con logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl shadow-xl mb-4"
          >
            <Shield className="h-10 w-10 text-white" />
          </motion.div>
          <h1 className="text-3xl font-black text-gray-900 mb-2">Panel de Administración</h1>
          <p className="text-gray-600">LiluTecno - Gestión de Catálogo</p>
        </div>

        {/* Formulario de login */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl shadow-2xl p-8 border border-gray-100"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Campo de usuario (solo visual) */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <User className="h-4 w-4 inline mr-2" />
                Usuario
              </label>
              <div className="relative">
                <input
                  type="text"
                  value="Administrador"
                  disabled
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-gray-600 cursor-not-allowed"
                />
              </div>
            </div>

            {/* Campo de contraseña */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <Lock className="h-4 w-4 inline mr-2" />
                Contraseña
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingresa tu contraseña de administrador"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  disabled={isLoading}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5" />
                  ) : (
                    <Eye className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Mensaje de error */}
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm"
              >
                {error}
              </motion.div>
            )}

            {/* Botón de login */}
            <motion.button
              type="submit"
              disabled={!password.trim() || isLoading}
              className={`w-full py-3 px-4 rounded-xl font-bold text-white transition-all ${
                !password.trim() || isLoading
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg hover:shadow-xl'
              }`}
              whileHover={!password.trim() || isLoading ? {} : { scale: 1.02 }}
              whileTap={!password.trim() || isLoading ? {} : { scale: 0.98 }}
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                  Verificando...
                </div>
              ) : (
                <>
                  <Shield className="h-5 w-5 inline mr-2" />
                  Acceder al Panel
                </>
              )}
            </motion.button>
          </form>

          {/* Información adicional */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="text-center text-sm text-gray-500">
              <p className="mb-2">🔒 Acceso restringido solo para administradores</p>
              <p className="text-xs">
                Sesión válida por 24 horas
              </p>
            </div>
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-8 text-sm text-gray-500"
        >
          <p>© 2024 LiluTecno - Panel de Administración Seguro</p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default AdminLogin;
