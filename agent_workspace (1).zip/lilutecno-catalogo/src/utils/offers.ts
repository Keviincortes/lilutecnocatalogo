import { Product } from '../types/Product';

export interface OfferInfo {
  hasOffer: boolean;
  discountPercentage: number;
  originalPrice: number;
  currentPrice: number;
  margin: number;
  offerType: 'SUPER_OFERTA' | 'GRAN_DESCUENTO' | 'OFERTA_ESPECIAL' | 'PRECIO_NORMAL';
  badge: string;
  urgencyLevel: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
}

export function calculateOffer(product: Product): OfferInfo {
  const currentPrice = product["PRECIO DE VENTA"];
  const cost = product.COSTO;
  const margin = ((currentPrice - cost) / cost) * 100;
  
  // Simulamos un precio "sugerido" más alto basado en el margen
  let originalPrice = currentPrice;
  let discountPercentage = 0;
  let hasOffer = false;
  let offerType: OfferInfo['offerType'] = 'PRECIO_NORMAL';
  let badge = '';
  let urgencyLevel: OfferInfo['urgencyLevel'] = 'NONE';

  // Si el margen es alto, simulamos que está en oferta
  if (margin > 80) {
    // Margen muy alto = súper oferta
    originalPrice = Math.round(currentPrice * 1.6); // 60% más caro "antes"
    discountPercentage = Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
    hasOffer = true;
    offerType = 'SUPER_OFERTA';
    badge = '¡SÚPER OFERTA!';
    urgencyLevel = 'HIGH';
  } else if (margin > 50) {
    // Margen alto = gran descuento
    originalPrice = Math.round(currentPrice * 1.4); // 40% más caro "antes"
    discountPercentage = Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
    hasOffer = true;
    offerType = 'GRAN_DESCUENTO';
    badge = 'GRAN DESCUENTO';
    urgencyLevel = 'HIGH';
  } else if (margin > 30) {
    // Margen medio = oferta especial
    originalPrice = Math.round(currentPrice * 1.25); // 25% más caro "antes"
    discountPercentage = Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
    hasOffer = true;
    offerType = 'OFERTA_ESPECIAL';
    badge = 'OFERTA ESPECIAL';
    urgencyLevel = 'MEDIUM';
  }

  // Agregar urgencia por stock bajo
  const stock = product["STOK ACTUAL"];
  if (stock > 0 && stock <= 5) {
    urgencyLevel = 'HIGH';
    if (!hasOffer) {
      badge = `¡Solo ${stock} unidades!`;
    }
  } else if (stock > 5 && stock <= 10) {
    if (urgencyLevel === 'NONE') urgencyLevel = 'MEDIUM';
  }

  return {
    hasOffer,
    discountPercentage,
    originalPrice,
    currentPrice,
    margin,
    offerType,
    badge,
    urgencyLevel
  };
}

export function getUrgencyColor(urgencyLevel: OfferInfo['urgencyLevel']) {
  switch (urgencyLevel) {
    case 'HIGH':
      return 'text-red-600 bg-red-100 border-red-200';
    case 'MEDIUM':
      return 'text-orange-600 bg-orange-100 border-orange-200';
    case 'LOW':
      return 'text-yellow-600 bg-yellow-100 border-yellow-200';
    default:
      return 'text-gray-600 bg-gray-100 border-gray-200';
  }
}

export function getOfferColor(offerType: OfferInfo['offerType']) {
  switch (offerType) {
    case 'SUPER_OFERTA':
      return 'bg-gradient-to-r from-red-500 to-pink-500 text-white';
    case 'GRAN_DESCUENTO':
      return 'bg-gradient-to-r from-orange-500 to-red-500 text-white';
    case 'OFERTA_ESPECIAL':
      return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white';
    default:
      return 'bg-gray-500 text-white';
  }
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0
  }).format(price);
}

export function getRandomOfferEndTime(): Date {
  const now = new Date();
  const hoursToAdd = Math.floor(Math.random() * 24) + 1; // Entre 1 y 24 horas
  return new Date(now.getTime() + hoursToAdd * 60 * 60 * 1000);
}

export function getCategoryImage(category: string): string {
  const imageMap: { [key: string]: string } = {
    'TELEVISOR': '/images/televisor-smart-65.jpeg',
    'AUDIO Y SONIDO': '/images/audio-headphones.jpg',
    'COCINA': '/images/cocina-appliances.jpg',
    'HOGAR': '/images/hogar-smart.png',
    'BEBES Y JUGUETES': '/images/bebes-juguetes.jpg',
    'CONTROLES Y CONSOLAS GAMER': '/images/gaming-console.jpg',
    'ACCESORIOS PARA CARRO': '/images/auto-accessories.jpg',
    'SALUD Y BELLEZA': '/images/belleza-cosmeticos.jpg',
    'CUIDADO PERSONAL': '/images/belleza-cosmeticos.jpg',
  };
  
  return imageMap[category] || '/images/televisor-smart-65.jpeg';
}
