import { Product } from '../types/Product';
import { formatPrice } from './offers';

export interface CustomerData {
  name: string;
  phone: string;
  address?: string;
  comments?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

// WhatsApp de LiluTecno - ENLACE CRÍTICO ACTUALIZADO
export const LILUTECNO_WHATSAPP = '573163026089'; // +57 316 302 6089
export const LILUTECNO_WHATSAPP_LINK = 'https://wa.link/4fo4p4'; // Enlace directo crítico actualizado

export function generateWhatsAppMessage(cartItems: CartItem[], customerData: CustomerData): string {
  // Generar número de pedido aleatorio
  const orderNumber = Math.floor(Math.random() * 900000) + 100000;
  const currentDate = new Date().toLocaleDateString('es-CO', {
    day: '2-digit',
    month: '2-digit', 
    year: 'numeric'
  });

  // Header de factura profesional
  const headerMessage = `📄 *FACTURA LILUTECNO*\n🏪 *Tecnología y Electrónicos*\n\n📅 Fecha: ${currentDate}\n🔢 Pedido: #LT${orderNumber}\n\n`;
  
  // Datos del cliente
  let customerMessage = `👤 *DATOS DEL CLIENTE:*\n`;
  customerMessage += `📛 Nombre: ${customerData.name}\n`;
  customerMessage += `📱 Teléfono: ${customerData.phone}\n`;
  
  if (customerData.address) {
    const addressParts = customerData.address.split(',');
    if (addressParts.length >= 2) {
      customerMessage += `📍 Ciudad: ${addressParts[addressParts.length - 1].trim()}\n`;
      customerMessage += `🏠 Dirección: ${addressParts.slice(0, -1).join(',').trim()}\n`;
    } else {
      customerMessage += `🏠 Dirección: ${customerData.address}\n`;
    }
  }
  
  if (customerData.comments) {
    customerMessage += `📧 Comentarios: ${customerData.comments}\n`;
  }
  customerMessage += `\n`;

  // Detalle de productos con formato de factura
  let productsMessage = `📦 *DETALLE DE PRODUCTOS:*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  let subtotal = 0;
  let totalItems = 0;

  cartItems.forEach(item => {
    const itemTotal = item["PRECIO DE VENTA"] * item.quantity;
    subtotal += itemTotal;
    totalItems += item.quantity;
    
    productsMessage += `• ${item.PRODUCTO}\n`;
    productsMessage += `  Cantidad: ${item.quantity}\n`;
    productsMessage += `  Precio Unit: ${formatPrice(item["PRECIO DE VENTA"])}\n`;
    productsMessage += `  Subtotal: ${formatPrice(itemTotal)}\n\n`;
  });
  
  productsMessage += `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  // Resumen de facturación
  const summaryMessage = `💰 *RESUMEN DE FACTURACIÓN:*\n`;
  const summaryDetails = `🛒 Total Productos: ${totalItems} unidad${totalItems > 1 ? 'es' : ''}\n`;
  const subtotalLine = `📊 Subtotal: ${formatPrice(subtotal)}\n`;
  const shippingLine = `🚚 Envío: Por coordinar\n`;
  const totalMessage = `💳 *TOTAL A PAGAR: ${formatPrice(subtotal)}*\n\n`;

  // Términos de venta
  const termsMessage = `📋 *TÉRMINOS DE VENTA:*\n`;
  const terms = `✅ Productos sujetos a disponibilidad\n✅ Precios pueden variar sin previo aviso\n✅ Garantía según fabricante\n✅ Envío a coordinar según ubicación\n\n`;

  // Siguiente paso profesional
  const nextStepMessage = `📞 *SIGUIENTE PASO:*\n`;
  const nextSteps = `Confirme su pedido y coordinaremos:\n• ✅ Disponibilidad de productos\n• 🚚 Costo y tiempo de envío\n• 💳 Método de pago preferido\n• 📦 Fecha de entrega estimada\n\n`;

  // Cierre profesional
  const closingMessage = `¡Gracias por elegir LiluTecno! 🚀\n*Su tecnología, nuestra pasión*`;

  // Mensaje completo formato factura
  return headerMessage + customerMessage + productsMessage + summaryMessage + summaryDetails + subtotalLine + shippingLine + totalMessage + termsMessage + terms + nextStepMessage + nextSteps + closingMessage;
}

export function openWhatsApp(message: string): void {
  // Codificar el mensaje para URL
  const encodedMessage = encodeURIComponent(message);
  
  // Usar siempre el enlace directo crítico actualizado
  const whatsappUrl = `${LILUTECNO_WHATSAPP_LINK}?text=${encodedMessage}`;
  
  // Abrir en nueva ventana/pestaña con optimizaciones de rendimiento
  const newWindow = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  
  // Fallback si el popup fue bloqueado
  if (!newWindow) {
    // Intentar con el método tradicional
    window.location.href = whatsappUrl;
  }
}

export function generateProductWhatsAppMessage(product: Product, customerData?: Partial<CustomerData>): string {
  const headerMessage = `🛍️ *CONSULTA LILUTECNO - SOLICITUD DE INFORMACIÓN*\n\n👋 ¡Hola! Me interesa obtener información sobre este producto:\n\n`;
  
  const productMessage = `📦 *PRODUCTO CONSULTADO:*\n`;
  const productDetails = `• ${product.PRODUCTO}\n`;
  const productPrice = `• Precio listado: ${formatPrice(product["PRECIO DE VENTA"])}\n`;
  const productCategory = `• Categoría: ${product.CATEGORIA}\n`;
  const stockStatus = product["STOK ACTUAL"] > 0 ? `• Stock: ${product["STOK ACTUAL"]} disponibles\n` : `• Stock: Consultar disponibilidad\n`;
  
  let customerMessage = '\n';
  if (customerData && (customerData.name || customerData.phone)) {
    customerMessage = `👤 *MIS DATOS DE CONTACTO:*\n`;
    if (customerData.name) customerMessage += `📛 Nombre: ${customerData.name}\n`;
    if (customerData.phone) customerMessage += `📱 Teléfono: ${customerData.phone}\n`;
    customerMessage += `\n`;
  }
  
  const questionMessage = `❓ *CONSULTAS ESPECÍFICAS:*\n`;
  const questions = `• ¿Confirma disponibilidad inmediata?\n• ¿Cuál es el precio final?\n• ¿Costo de envío a mi ciudad?\n• ¿Métodos de pago disponibles?\n• ¿Tiempo de entrega estimado?\n• ¿Incluye garantía?\n\n`;
  
  const closingMessage = `⚡ Estoy interesado/a en realizar la compra si las condiciones son favorables.\n\n¡Gracias por su atención! 🚀`;
  
  return headerMessage + productMessage + productDetails + productPrice + productCategory + stockStatus + customerMessage + questionMessage + questions + closingMessage;
}

export function isValidPhoneNumber(phone: string): boolean {
  // Validar números colombianos (300-320, 350-359, etc.)
  const colombianPhoneRegex = /^(3\d{9}|[1-8]\d{6,7})$/;
  const cleanPhone = phone.replace(/\D/g, '');
  return colombianPhoneRegex.test(cleanPhone);
}

export function formatPhoneNumber(phone: string): string {
  const cleanPhone = phone.replace(/\D/g, '');
  
  if (cleanPhone.length === 10 && cleanPhone.startsWith('3')) {
    // Celular: 300 123 4567
    return `${cleanPhone.substring(0, 3)} ${cleanPhone.substring(3, 6)} ${cleanPhone.substring(6)}`;
  } else if (cleanPhone.length === 7) {
    // Fijo: 123 4567
    return `${cleanPhone.substring(0, 3)} ${cleanPhone.substring(3)}`;
  }
  
  return phone;
}

export function validateCustomerData(data: CustomerData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!data.name || data.name.trim().length < 2) {
    errors.push('El nombre debe tener al menos 2 caracteres');
  }
  
  if (!data.phone || !isValidPhoneNumber(data.phone)) {
    errors.push('Ingresa un número de teléfono válido');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Configuración para diferentes países (por si se expande)
export const WHATSAPP_CONFIG = {
  colombia: {
    countryCode: '57',
    phoneFormat: /^3\d{9}$/,
    examplePhone: '300 123 4567'
  },
  // Se pueden agregar más países después
};
