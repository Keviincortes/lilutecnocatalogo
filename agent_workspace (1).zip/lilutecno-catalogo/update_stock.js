// Script para actualizar stock de productos en LiluTecno
import fs from 'fs';
import path from 'path';

const PRODUCTS_FILE = './public/productos_con_imagenes.json';

// Leer productos actuales
const products = JSON.parse(fs.readFileSync(PRODUCTS_FILE, 'utf8'));

console.log(`📦 Actualizando stock de ${products.length} productos...`);

// Actualizar stock de productos
const updatedProducts = products.map(product => {
  // Asignar stock realista basado en la categoría y precio
  let newStock = 0;
  
  const price = product["PRECIO DE VENTA"];
  const category = product.CATEGORIA;
  
  // Lógica de stock basada en categoría y precio
  if (category === 'TELEVISOR') {
    newStock = price > 1500000 ? 3 : price > 800000 ? 8 : 15;
  } else if (category === 'AUDIO') {
    newStock = price > 300000 ? 12 : 25;
  } else if (category === 'GAMING') {
    newStock = price > 200000 ? 15 : 30;
  } else if (category === 'ACCESORIOS') {
    newStock = 50;
  } else if (category === 'CABLES') {
    newStock = 100;
  } else {
    // Stock general para otras categorías
    newStock = price > 500000 ? 5 : price > 100000 ? 20 : 40;
  }
  
  // Agregar variabilidad realista (±30%)
  const variance = Math.floor(newStock * 0.3);
  newStock = newStock + Math.floor(Math.random() * (variance * 2)) - variance;
  
  // Asegurar que no sea negativo
  newStock = Math.max(1, newStock);
  
  // Algunos productos sin stock para realismo (5%)
  if (Math.random() < 0.05) {
    newStock = 0;
  }
  
  return {
    ...product,
    "STOK ACTUAL": newStock,
    "STOCK INICIAL": newStock,
    "ENTRADAS": newStock,
    "SALIDAS": 0
  };
});

// Guardar productos actualizados
fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(updatedProducts, null, 2));

// Estadísticas
const inStock = updatedProducts.filter(p => p["STOK ACTUAL"] > 0).length;
const outOfStock = updatedProducts.length - inStock;
const totalValue = updatedProducts.reduce((sum, p) => sum + (p["PRECIO DE VENTA"] * p["STOK ACTUAL"]), 0);

console.log(`✅ Stock actualizado exitosamente!`);
console.log(`📊 Estadísticas:`);
console.log(`   - Productos con stock: ${inStock}`);
console.log(`   - Productos sin stock: ${outOfStock}`);
console.log(`   - Valor total inventario: $${totalValue.toLocaleString()}`);
console.log(`   - Stock promedio: ${Math.round(updatedProducts.reduce((sum, p) => sum + p["STOK ACTUAL"], 0) / updatedProducts.length)}`);
